<?php

Route::group(
    ['middleware' => ['web', 'auth'], 'module' => 'ModernSales', 'namespace' => 'App\Modules\ModernSales\Controllers'], function () {
        Route::get('/modernSales', 'ModernSalesController@index');
        Route::get('/mts-visit', 'ModernVisitController@mts_visit');
        Route::get('/mts-partyList', 'ModernVisitController@mts_partyList');
        Route::get('/mts-order-process/{partyid}/{routeid}', 'ModernVisitController@mts_order_process');
        Route::get('/mts-category-products', 'ModernVisitController@mts_category_products');
        Route::post('/mts-add-to-cart', 'ModernVisitController@mts_add_to_cart_products');

		Route::get('/mts-bucket/{routeid}/{partyid}', 'ModernVisitController@mts_bucket');

		Route::post('/mts-items-edit', 'ModernVisitController@mts_items_edit');
		Route::post('/mts-edit-submit', 'ModernVisitController@mts_items_edit_submit');
		Route::post('/mts-items-delete', 'ModernVisitController@mts_items_delete');

		Route::get('/mts-confirm-order/{orderid}/{partyid}/{routeid}', 'ModernVisitController@mts_confirm_order');

		Route::get('/mts-confirm-order/{orderid}/{partyid}/{routeid}', 'ModernVisitController@mts_confirm_order');
		Route::get('/delete-wastage/{orderid}/{retailderid}/{routeid}', 'ModernVisitController@mts_delete_order');


		// Report for field Executive

		Route::get('/mts-order-report', 'ModernExecutiveReportController@mts_order_report');
		Route::post('/mts-order-report-list', 'ModernExecutiveReportController@mts_order_report_list');
		Route::get('/mts-order-details/{orderMainId}', 'ModernExecutiveReportController@mts_order_details');

		Route::get('/mts-delivery-report', 'ModernExecutiveReportController@mts_delivery_report');
		Route::post('/mts-delivery-report-list', 'ModernExecutiveReportController@mts_delivery_report_list');
		Route::get('/mts-delivery-details/{orderMainId}', 'ModernExecutiveReportController@mts_delivery_details');

		
		/////////////////////Md. Sazzadul islam////////////////////
		Route::get('/modern-delivery', 'ModernDeliveryController@modern_delivery');
		Route::get('/modern-delivery-list', 'ModernDeliveryController@ssg_delivery_list');

		Route::get('/orderDelivery-edit/{wastageMainId}/{foMainId}', 'ModernDeliveryController@ssg_order_edit');
		Route::post('/orderDelivery-edit-submit', 'ModernDeliveryController@ssg_modern_edit_submit');

		
		Route::get('/moderndelivery', 'ModernDeliveryController@ssg_report_order_delivery');
		Route::post('/moderndelivery-list', 'ModernDeliveryController@ssg_report_order_list');
		Route::get('/modernorder-details/{orderMainId}', 'ModernDeliveryController@ssg_order_details');
    }
);