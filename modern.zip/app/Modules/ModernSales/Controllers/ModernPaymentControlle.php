<?php

namespace App\Modules\ModernSales\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Auth;
use Session;
use DB;
use Validator;
class ModernPaymentControlle extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   public function mts_opening_route()
    {

        $selectedMenu   = 'Visit';         // Required Variable
        $pageTitle      = 'Visit';        // Page Slug Title

         $routeResult = DB::table('mts_route')
                        ->where('status',0)
                        ->get();
      

        return view('ModernSales::sales/payment/routeManage', compact('selectedMenu','pageTitle','routeResult'));
    }

     public function mts_opening_outlet(Request $request)
    {

        $routeid = $request->get('route');


        $ledgerCheckParty = DB::table('mts_outlet_ledger')
                        ->groupBy('customer_id')                    
                        ->get();

        $customer_id = array();

         foreach($ledgerCheckParty as $checkParty) {
                    $customer_id[]= $checkParty->customer_id;
                }

        $resultParty = DB::table('mts_customer_list')
                        ->select('customer_id','name','route_id','owner','address','opening_balance','sap_code','status')
                        ->where('global_company_id', Auth::user()->global_company_id)
                        ->where('route_id', $routeid)
                        ->whereNotIn('customer_id', $customer_id)
                        ->where('status', 0)
                        ->orderBy('name','ASC')                    
                        ->get();
      //dd($customer_id);

        return view('ModernSales::sales/payment/outletList', compact('resultParty','routeid'));
    }


    public function mts_add_opening_balance(Request $request){

    	$countRows = count($request->get('opening_balance'));
    	

    	for($m=0;$m<$countRows;$m++)
            {
            	

                if($request->get('opening_balance')[$m]!='')
                {
                	
                    DB::table('mts_customer_list')->where('customer_id',$request->get('customer_id')[$m])->update(
                        [
                            'opening_balance'   => $request->get('opening_balance')[$m]
                        ]
                    );

                     DB::table('mts_outlet_ledger')->insert(
                        [
                            'ledger_date'        	=> date('Y-m-d h:i:s'),
                            'customer_id'          	=> $request->get('customer_id')[$m],
                            'party_sap_code'     	=> $request->get('sap_code')[$m],
                            'opening_balance'     	=> $request->get('opening_balance')[$m],
                            'debit'     			=> $request->get('opening_balance')[$m],
                            'credit'     			=> 0,
                            'closing_balance'     	=> $request->get('opening_balance')[$m],
                            'trans_type'            => 'opening',
                            'entry_by'           	=> Auth::user()->id,
                            'entry_date'         	=> date('Y-m-d h:i:s')

                        ]
                    );

                }

            }

            return Redirect::to('/mts-opening-route')->with('success', 'Successfully Added Add To Cart.');
    }


    public function credit_adjustment()
    {
        $selectedMenu   = 'Credit Adjustment';         // Required Variable
        $pageTitle      = 'Adjustment List';       // Required Variable
        
        
        $this->outlet_in_charge  = Auth::user()->id;
        $this->user_type_id     = Auth::user()->user_type_id;
        
        
        $user_business_type=DB::select("select * from users where id='".$this->outlet_in_charge."'");
        
        foreach ($user_business_type as $type)
        {

            $user_type=$type->business_type_id;
            $outlet_name=$type->display_name;

        }

            $outletList = DB::table('mts_customer_list') 
                        ->join('mts_customer_define_executive', 'mts_customer_define_executive.customer_id', '=', 'mts_customer_list.customer_id')
                        ->where('mts_customer_define_executive.executive_id', Auth::user()->id)
                        ->where('mts_customer_list.status',0)
                        ->orderBy('mts_customer_list.name','ASC')    
                        ->get();

        $bankList = DB::table('tbl_master_bank')
                        ->where('status',0)
                        ->orderBy('bank_name','asc')
                        ->get();

        $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id')
                       ->where('mts_outlet_payments.trans_type','adjustment')
                       ->where('mts_outlet_payments.entry_by',Auth::user()->id)        
                        ->get();
 

        return view('ModernSales::payment/credit_adjustment')->with('outletList',$outletList)
        ->with('outletPayment',$outletPayment)
        ->with('user_business_type',$user_type)
        ->with('outlet_name',$outlet_name)
        ->with('selectedMenu',$selectedMenu)
        ->with('pageTitle',$pageTitle)
        ->with('bankList',$bankList);

    }

    public function credit_adjustment_list(Request $request)
    {
       $selectedMenu   = 'Credit Adjustment';         // Required Variable
        $pageTitle      = 'Adjustment List';       // Required Variable
        
        
        $this->outlet_in_charge  = Auth::user()->id;
        $this->user_type_id     = Auth::user()->user_type_id;
        
        $fromdate   = date('Y-m-d', strtotime($request->get('fromdate')));
        $todate     = date('Y-m-d', strtotime($request->get('todate')));

        
        
        $user_business_type=DB::select("select * from users where id='".$this->outlet_in_charge."'");
        
        foreach ($user_business_type as $type)
        {

            $user_type=$type->business_type_id;
            $outlet_name=$type->display_name;

        }
        
        if($fromdate!='' && $todate!='')
        {
  
            $outletList = DB::table('mts_customer_list')
                            ->orderBy('customer_id','asc')
                            ->get();

            $outletPayment= DB::table('mts_outlet_payments')
                           ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                           ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id')
                           ->where('mts_outlet_payments.trans_type','adjustment')
                           ->where('mts_outlet_payments.entry_by',Auth::user()->id) 
                           ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))        
                            ->get();

           // dd($outletPayment);
        }

        return view('ModernSales::payment/credit_adjustment_list')->with('outletList',$outletList)
        ->with('outletPayment',$outletPayment)
        ->with('user_business_type',$user_type)
        ->with('outlet_name',$outlet_name)
        ->with('selectedMenu',$selectedMenu)
        ->with('pageTitle',$pageTitle);

    }

    public function credit_adjustment_process(Request $req)
    {
        if ($req->isMethod('post')) 
        {
            $selectedMenu   = 'Outlet pay';         // Required Variable
            $pageTitle      = 'Payment List';       // Required Variable 
            $payment_type   =   $req->input('payment_type');
            $customer_info  =   $req->input('party_id');
            $customer       = explode('-',$customer_info);
            $party_id       = $customer[0];
            $sap_code       = $customer[1];

            $autoNo = rand(100,1000);
           
            $payment_no = 'AE'.'-'.$sap_code.'-'.date('dmy').'-'.$autoNo;

            //dd($payment_no);
            
            if($payment_type == 'CHEQUE' || $payment_type=='ON-LINE')
            {

                if($payment_type=="CHEQUE")
                {   $bank_info  =   $req->input('bank_name');
                    $bank_info_list   = explode('-',$bank_info);
                    $bank_id       = $bank_info_list[0];
                    $bank_name       = $bank_info_list[1];
                    $bank_ac_no       = $bank_info_list[2];
                    //$bank_name      =   $req->input('bank_name');
                    $branch_name    =   $req->input('branch_name');
                    $cheque_date    =   date_create($req->input('cheque_date'));
                    $cheque_date    =   date_format($cheque_date,"Y-m-d");
                }

                if($payment_type=="ON-LINE")
                {   
                    $bank_name      =   $req->input('ssgbank_name'); 
                    $bank_id       = ''; 
                    $bank_ac_no       = '';
                    $branch_name    =   '';
                    $cheque_date    =   '';
                    $cheque_date    =   '';
                }
                


            } else {

                $bank_name      =   '';
                $branch_name    =   '';
                $acc_no         =   '';
                $cheque_no      =   '';
                $cheque_date    =   '';
                $bank_id       = ''; 
                $bank_ac_no       = '';
            }
            
            $payment_remarks    =   $req->input('payment_remarks');
            $trans_amount       =   $req->input('trans_amount');
            $adjust_amount       =   $req->input('adjust_amount');
            

            $trans_date     =   date('Y-m-d h:i:s'); // system date
            
            
            $ref_no =   $req->input('ref_no');

            $user_id        =   Auth::user()->id;
            $entryDate = date('Y-m-d h:i:s');

            $this->user_type_id     = Auth::user()->user_type_id;


            $this->outlet_in_charge  = Auth::user()->id;

            // image upload 

                $main_image_file = '';
                if($req->file('user_photo')!='')
                {
                    $validator = Validator::make($req->all(), [
                    'user_photo' => 'required|max:10000|mimes:jpg,jpeg,png,gif',
                    ]);

                    if ($validator->fails()) {
                        return Redirect::back()
                                    ->withErrors($validator)
                                    ->withInput($req->all);
                    }

                    $photo = $req->file('user_photo');
                    $fath1 = 'uploads/modernPayment';
                    $main_image_file = 'payment'.'_'.$party_id.'_'.time().'.'.$photo->getClientOriginalExtension();
                    $success = $photo->move($fath1, $main_image_file);
                } 

            if($payment_type=="CHEQUE")
            {
 

                DB::table('mts_outlet_payments')->insert(
                    [
                        'customer_id'           => $party_id,
                        'payment_no'            => $payment_no,
                        'outlet_in_charge'      => $this->outlet_in_charge,
                        'payment_type'          => $payment_type,
                        'bank_info_id'          => $bank_id,
                        'bank_name'             => $bank_name,
                        'acc_no'                => $bank_ac_no,
                        'branch_name'           => $branch_name,
                        'cheque_date'           => $cheque_date,
                        'ref_no'                => $ref_no,
                        'payment_amount'        => $trans_amount,
                        'adjust_amount'         => $adjust_amount,
                        'trans_type'            => 'adjustment',
                        'trans_date'            => $trans_date,
                        'upload_image'          => $main_image_file,
                        'entry_by'              => $this->outlet_in_charge,
                        'entry_date'            => $entryDate,
                        'payment_remarks'       => $payment_remarks,
                    ]
                );

            } else if($payment_type=="ON-LINE"){


                DB::table('mts_outlet_payments')->insert(
                    [
                        'customer_id'           => $party_id,
                        'payment_no'            => $payment_no,
                        'outlet_in_charge'      => $this->outlet_in_charge,
                        'payment_type'          => $payment_type,
                        'bank_info_id'          => $bank_name,
                        'ref_no'                => $ref_no,
                        'payment_amount'        => $trans_amount,
                        'adjust_amount'         => $adjust_amount,
                        'trans_type'             => 'adjustment',
                        'trans_date'            => $trans_date,
                        'upload_image'          => $main_image_file,
                        'entry_by'              => $this->outlet_in_charge,
                        'entry_date'            => $entryDate,
                        'payment_remarks'       => $payment_remarks,
                    ]
                );



            } else {

                DB::table('mts_outlet_payments')->insert(
                    [
                        'customer_id'            => $party_id,
                        'payment_no'             => $payment_no,
                        'outlet_in_charge'       => $this->outlet_in_charge,
                        'payment_type'           => $payment_type,
                        'ref_no'                 => $ref_no,
                        'payment_amount'         => $trans_amount,
                        'adjust_amount'          => $adjust_amount,
                        'trans_type'             => 'adjustment',
                        'trans_date'             => $trans_date,
                        'upload_image'           => $main_image_file,
                        'entry_by'               => $this->outlet_in_charge,
                        'entry_date'             => $entryDate,
                        'payment_remarks'        => $payment_remarks,
                    ]
                );



            }
            

            return Redirect::to('/credit-adjustment')->with('success', 'Successfully Adjustment Added.');

        }

    }

    // Md. Sazzadul islam 
    public function outlet_payments()
    {
        $selectedMenu   = 'Outlet pay';         // Required Variable
        $pageTitle      = 'Payment List';       // Required Variable
        
        
        $this->outlet_in_charge  = Auth::user()->id;
        $this->user_type_id     = Auth::user()->user_type_id;
        
        
        $user_business_type=DB::select("select * from users where id='".$this->outlet_in_charge."'");
        
        foreach ($user_business_type as $type)
        {

            $user_type=$type->business_type_id;
            $outlet_name=$type->display_name;

        }

        $outletList = DB::table('mts_customer_list') 
                        ->join('mts_customer_define_executive', 'mts_customer_define_executive.customer_id', '=', 'mts_customer_list.customer_id')
                        ->where('mts_customer_define_executive.executive_id', Auth::user()->id)
                        ->where('mts_customer_list.status',0)
                        ->orderBy('mts_customer_list.name','ASC')    
                        ->get();

      $bankList = DB::table('tbl_master_bank')
                        ->where('status',0)
                        ->orderBy('bank_name','asc')
                        ->get();
        $ssgbankList = DB::table('tbl_master_bank')
                        ->where('status',0)
                        ->orderBy('bank_name','asc')
                        ->get();

        $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id')
                       ->where('mts_outlet_payments.trans_type','payment')
                       ->where('mts_outlet_payments.entry_by',Auth::user()->id)        
                        ->get();

       // dd($outletPayment);
 

        return view('ModernSales::payment/outlet_credit')->with('outletList',$outletList)
        ->with('outletPayment',$outletPayment)
        ->with('user_business_type',$user_type)
        ->with('outlet_name',$outlet_name)
        ->with('selectedMenu',$selectedMenu)
        ->with('bankList',$bankList)
        ->with('ssgbankList',$ssgbankList)
        ->with('pageTitle',$pageTitle);

    }

    public function outlet_payment_list(Request $request)
    {
        $selectedMenu   = 'Outlet pay';         // Required Variable
        $pageTitle      = 'Payment List';       // Required Variable
        
        
        $this->outlet_in_charge  = Auth::user()->id;
        $this->user_type_id     = Auth::user()->user_type_id;
        
        $fromdate   = date('Y-m-d', strtotime($request->get('fromdate')));
        $todate     = date('Y-m-d', strtotime($request->get('todate')));

       
        
        $user_business_type=DB::select("select * from users where id='".$this->outlet_in_charge."'");
        
        foreach ($user_business_type as $type)
        {

            $user_type=$type->business_type_id;
            $outlet_name=$type->display_name;

        }
        
        if($fromdate!='' && $todate!='')
        {
  
            $outletList = DB::table('mts_customer_list')
                            ->orderBy('customer_id','asc')
                            ->get();

            $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id')
                       ->where('mts_outlet_payments.trans_type','payment')
                           ->where('mts_outlet_payments.entry_by',Auth::user()->id)
                           ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))        
                            ->get();
        }

        return view('ModernSales::payment/outlet_credit_list')->with('outletList',$outletList)
        ->with('outletPayment',$outletPayment)
        ->with('user_business_type',$user_type)
        ->with('outlet_name',$outlet_name)
        ->with('selectedMenu',$selectedMenu)
        ->with('pageTitle',$pageTitle);

    }

    public function outlet_paymnet_process(Request $req)
    {
        if ($req->isMethod('post')) 
        {
            $selectedMenu   = 'Outlet pay';         // Required Variable
            $pageTitle      = 'Payment List';       // Required Variable 
            $payment_type   =   $req->input('payment_type');
            $customer_info  =   $req->input('party_id');
            $customer       = explode('-',$customer_info);
            $party_id       = $customer[0];
            $sap_code       = $customer[1];

           

            $autoNo = rand(100,1000);
           
            $payment_no = 'PE'.'-'.$sap_code.'-'.date('dmy').'-'.$autoNo;

            $supervisorList = DB::table('mts_role_hierarchy')
                        ->where('status',0)                        
                        ->where('officer_id',Auth::user()->id) 
                        ->first();
            
            if($payment_type == 'CHEQUE' || $payment_type=='ON-LINE' || $payment_type=="PAY-ORDER")
            {

                if($payment_type=="CHEQUE" || $payment_type=="PAY-ORDER")
                {   

                    $bank_info  =   $req->input('bank_name');
                    $bank_info_list   = explode('-',$bank_info);
                    $bank_id       = $bank_info_list[0];
                    $bank_name       = $bank_info_list[1];
                    $bank_ac_no       = $bank_info_list[2];
                    //$bank_name      =   $req->input('bank_name');
                    $branch_name    =   $req->input('branch_name');
                    $cheque_date    =   date_create($req->input('cheque_date'));
                    $cheque_date    =   date_format($cheque_date,"Y-m-d");
                }

                if($payment_type=="ON-LINE")
                {   
                    $bank_name      =   $req->input('ssgbank_name');
                    $branch_name    =   '';
                    $cheque_date    =   '';
                    $cheque_date    =   '';
                    $bank_ac_no     = '';
                }
                


            } else {
                $bank_ac_no     = '';
                $bank_name      =   '';
                $branch_name    =   '';
                $acc_no         =   '';
                $cheque_no      =   '';
                $cheque_date    =   '';
            }
            
            $payment_remarks    =   $req->input('payment_remarks');
            $trans_amount       =   $req->input('trans_amount');
            $adjust_amount       =   $req->input('adjust_amount'); 
            $trans_date     =   date('Y-m-d h:i:s'); // system date 
            $ref_no =   $req->input('ref_no');

            $user_id        =   Auth::user()->id;
            $entryDate = date('Y-m-d h:i:s');

            $this->user_type_id     = Auth::user()->user_type_id;


            $this->outlet_in_charge  = Auth::user()->id;

            if($payment_type=="CHEQUE" || $payment_type=="PAY-ORDER")
            {
                // image upload 

                $main_image_file = '';
                if($req->file('user_photo')!='')
                {
                    $validator = Validator::make($req->all(), [
                    'user_photo' => 'required|max:10000|mimes:jpg,jpeg,png,gif',
                    ]);

                    if ($validator->fails()) {
                        return Redirect::back()
                                    ->withErrors($validator)
                                    ->withInput($req->all);
                    }

                    $photo = $req->file('user_photo');
                    $fath1 = 'uploads/modernPayment';
                    $main_image_file = 'payment'.'_'.$party_id.'_'.time().'.'.$photo->getClientOriginalExtension();
                    $success = $photo->move($fath1, $main_image_file);
                } 

                //dd($req->file('user_photo'));

                DB::table('mts_outlet_payments')->insert(
                    [
                        'customer_id'           => $party_id,
                        'management_id'         => $supervisorList->management_id,
                        'manager_id'            => $supervisorList->manager_id,
                        'executive_id'          => $supervisorList->executive_id,
                        'officer_id'            => Auth::user()->id,
                        'payment_no'            => $payment_no,
                        'outlet_in_charge'      => $this->outlet_in_charge,
                        'payment_type'          => $payment_type,
                        'bank_info_id'          => $bank_id,
                        'bank_name'             => $bank_name,
                        'acc_no'                => $bank_ac_no,
                        'branch_name'           => $branch_name,
                        'cheque_date'           => $cheque_date,
                        'ref_no'                => $ref_no,
                        'payment_amount'        => $trans_amount,
                        'adjust_amount'         => $adjust_amount,
                        'trans_date'            => $trans_date,
                        'upload_image'          => $main_image_file,
                        'entry_by'              => $this->outlet_in_charge,
                        'entry_date'            => $entryDate,
                        'payment_remarks'       => $payment_remarks,
                    ]
                );

            } else if($payment_type=="ON-LINE"){


                DB::table('mts_outlet_payments')->insert(
                    [
                        'customer_id'           => $party_id,
                        'management_id'         => $supervisorList->management_id,
                        'manager_id'            => $supervisorList->manager_id,
                        'executive_id'          => $supervisorList->executive_id,
                        'officer_id'            => Auth::user()->id,
                        'payment_no'            => $payment_no,
                        'outlet_in_charge'      => $this->outlet_in_charge,
                        'payment_type'          => $payment_type,
                        'bank_info_id'          => $bank_name,
                        'ref_no'                => $ref_no,
                        'payment_amount'        => $trans_amount,
                        'adjust_amount'         => $adjust_amount,
                        'trans_date'            => $trans_date,
                        'entry_by'              => $this->outlet_in_charge,
                        'entry_date'            => $entryDate,
                        'payment_remarks'       => $payment_remarks,
                    ]
                );



            } else {


                DB::table('mts_outlet_payments')->insert(
                    [
                        'customer_id'            => $party_id,
                        'management_id'          => $supervisorList->management_id,
                        'manager_id'             => $supervisorList->manager_id,
                        'executive_id'           => $supervisorList->executive_id,
                        'officer_id'             => Auth::user()->id,
                        'payment_no'             => $payment_no,
                        'outlet_in_charge'       => $this->outlet_in_charge,
                        'payment_type'           => $payment_type,
                        'ref_no'                 => $ref_no,
                        'payment_amount'         => $trans_amount,
                        'adjust_amount'          => $adjust_amount,
                        'trans_date'             => $trans_date,
                        'entry_by'               => $this->outlet_in_charge,
                        'entry_date'             => $entryDate,
                        'payment_remarks'        => $payment_remarks,
                    ]
                );



            }
            

            return Redirect::to('/outlet_payments')->with('success', 'Successfully Payment Added.');

        }

    }



    public function admin_payments_con()
    {
        $selectedMenu   = 'Outlet pay';         // Required Variable
        $pageTitle      = 'Payment List';       // Required Variable
        
        
        $this->outlet_in_charge  = Auth::user()->id;
        $this->user_type_id     = Auth::user()->user_type_id;
        
        
        $user_business_type=DB::select("select * from users where id='".$this->outlet_in_charge."'");
        
        foreach ($user_business_type as $type)
        {

            $user_type=$type->business_type_id;
            $outlet_name=$type->display_name;

        }

        
        $outletList = DB::table('mts_customer_list')
                            ->orderBy('customer_id','asc')
                            ->get(); 

        $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id')
                       ->where('mts_outlet_payments.ack_status','NO')       
                        ->get();

        $managementlist = DB::table('mts_role_hierarchy')
          ->join('users', 'users.id', '=', 'mts_role_hierarchy.management_id')     
          ->where('mts_role_hierarchy.supervisor_id', Auth::user()->id)
          ->groupBy('mts_role_hierarchy.management_id')
          ->get();


        return view('ModernSales::payment/admin/outlet_credit', compact('selectedMenu','pageTitle','managementlist','outletList','outletPayment','outlet_name'));

       

    }
    

    public function admin_payments_con_list(Request $request)
    {
        $selectedMenu   = 'Outlet pay';         // Required Variable
        $pageTitle      = 'Payment List';       // Required Variable
        
        
        $this->outlet_in_charge  = Auth::user()->id;
        $this->user_type_id     = Auth::user()->user_type_id;
        
        $fromdate   = date('Y-m-d', strtotime($request->get('fromdate')));
        $todate     = date('Y-m-d', strtotime($request->get('todate')));

        $customer = DB::table('mts_customer_list')
                            ->orderBy('customer_id','asc')
                            ->get();
        
        $user_business_type=DB::select("select * from users where id='".$this->outlet_in_charge."'");
        
        foreach ($user_business_type as $type)
        {

            $user_type=$type->business_type_id;
            $outlet_name=$type->display_name;

        }
        
        if($fromdate!='' && $todate!='')
        {


            $outletList = DB::table('mts_customer_list')
                            ->orderBy('customer_id','asc')
                            ->get();

            $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id')
                       ->where('mts_outlet_payments.ack_status','NO') 
                           ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))        
                            ->get();

        }

        return view('ModernSales::payment/admin/outlet_credit_list')->with('outletList',$outletList)
        ->with('outletPayment',$outletPayment)
        ->with('user_business_type',$user_type)
        ->with('outlet_name',$outlet_name)
        ->with('selectedMenu',$selectedMenu)
        ->with('customer',$customer)
        ->with('pageTitle',$pageTitle);

    }


    public function mts_admin_payment()
    {
        $selectedMenu   = 'Customer payment';         // Required Variable
        $pageTitle      = 'Payment List';       // Required Variable
        
        

        $customer = DB::table('mts_customer_list')
                            ->orderBy('customer_id','asc')
                            ->get();

        $outletPayment= DB::table('mts_customer_list')
                       ->JOIN('mts_outlet_payments','mts_outlet_payments.customer_id','mts_customer_list.customer_id')
                       ->where('mts_outlet_payments.ack_status','NO')       
                        ->get();


        return view('ModernSales::payment/admin/payment_report',compact('customer','outletPayment','selectedMenu','pageTitle'));

    }
    

    public function mts_admin_payment_list(Request $request)
    {
        $selectedMenu   = 'Customer payment';         // Required Variable
        $pageTitle      = 'Payment List';       // Required Variable
        
        
        $fromdate       = date('Y-m-d', strtotime($request->get('fromdate')));
        $todate         = date('Y-m-d', strtotime($request->get('todate')));
        $management = $request->get('management_id');
        $manager    = $request->get('manager_id');
        $executive  = $request->get('executive_id');
        $officer    = $request->get('fos');
        $customer_id    = $request->get('customer');
        $payment_type   = $request->get('payment_type');
        
        if($fromdate!='' && $todate!='' && $management!='' && $manager!='' && $executive!='' && $officer!='' && $customer_id=='' && $payment_type=='')
        { 
            $outletPayment= DB::table('mts_customer_list')
                           ->JOIN('mts_outlet_payments','mts_outlet_payments.customer_id','mts_customer_list.customer_id')
                           ->where('mts_outlet_payments.ack_status','NO')
                           ->where('mts_outlet_payments.management_id', $management)
                           ->where('mts_outlet_payments.manager_id', $manager)
                           ->where('mts_outlet_payments.executive_id',$executive)
                           ->where('mts_outlet_payments.officer_id',$officer)
                           ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))
                           ->get();

        }
        elseif($fromdate!='' && $todate!='' && $management!='' && $manager!='' && $executive!='' && $officer=='' && $customer_id=='' && $payment_type=='')
        { 
            $outletPayment= DB::table('mts_customer_list')
                           ->JOIN('mts_outlet_payments','mts_outlet_payments.customer_id','mts_customer_list.customer_id')
                           ->where('mts_outlet_payments.ack_status','NO')
                           ->where('mts_outlet_payments.management_id', $management)
                           ->where('mts_outlet_payments.manager_id', $manager)
                           ->where('mts_outlet_payments.executive_id',$executive) 
                           ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))
                           ->get();

        }
        elseif($fromdate!='' && $todate!='' && $management!='' && $manager!='' && $executive!='' && $officer!='' && $customer_id!='' && $payment_type=='')
        {
            $outletPayment= DB::table('mts_customer_list')
                           ->JOIN('mts_outlet_payments','mts_outlet_payments.customer_id','mts_customer_list.customer_id')
                           ->where('mts_outlet_payments.ack_status','NO')
                           ->where('mts_outlet_payments.customer_id',$customer_id)
                           ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))        
                            ->get();

        }
        elseif($fromdate!='' && $todate!='' && $management!='' && $manager!='' && $executive!='' && $officer!='' && $customer_id!='' && $payment_type!='')
        {


            $outletPayment= DB::table('mts_customer_list')
                           ->JOIN('mts_outlet_payments','mts_outlet_payments.customer_id','mts_customer_list.customer_id')
                           ->where('mts_outlet_payments.ack_status','NO')
                           ->where('mts_outlet_payments.customer_id',$customer_id)
                           ->where('mts_outlet_payments.trans_type',$payment_type)
                           ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))        
                            ->get();

        }

        return view('ModernSales::payment/admin/payment_report_list',compact('outletPayment','selectedMenu','pageTitle'));

    }

    public function app_admin_payment($id, $status)
    {
        if($status=='APPROVE')
        {
            DB::table('mts_outlet_payments')->where('transaction_id', $id)->update(
                [
                    'ack_by'           => Auth::user()->id,
                    'ack_date'           => date('Y-m-d'),
                    'ack_status'           => 'APPROVE',
                ]
            );
        }elseif($status=='NOT_APPROVE'){
            DB::table('mts_outlet_payments')->where('transaction_id', $id)->update(
                [
                    'ack_by'           => Auth::user()->id,
                    'ack_date'           => date('Y-m-d'),
                    'ack_status'           => 'NOT_APPROVE',
                ]
            );
        }else{
            return Redirect::to('/admin_payments_con')->with('error', 'Sorry Payment Not Added.');
        }

        return Redirect::to('/admin_payments_con')->with('success', 'Successfully Payment Added.');

    }

    public function accounts_payments_con()
    {
        $selectedMenu   = 'Outlet pay';         // Required Variable
        $pageTitle      = 'Payment List';       // Required Variable
        
        
        $this->outlet_in_charge  = Auth::user()->id;
        $this->user_type_id     = Auth::user()->user_type_id;
        
        
        $user_business_type=DB::select("select * from users where id='".$this->outlet_in_charge."'");
        
        foreach ($user_business_type as $type)
        {

            $user_type=$type->business_type_id;
            $outlet_name=$type->display_name;

        }
 

        $outletList = DB::table('mts_customer_list')
                            ->orderBy('customer_id','asc')
                            ->get();

        $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id') 
                       ->where('mts_outlet_payments.ack_status','APPROVE')
                       ->get();
 

        return view('ModernSales::payment/account/outlet_credit')->with('outletList',$outletList)
        ->with('outletPayment',$outletPayment)
        ->with('user_business_type',$user_type)
        ->with('outlet_name',$outlet_name)
        ->with('selectedMenu',$selectedMenu)
        ->with('pageTitle',$pageTitle);

    }
    

    public function accounts_payments_con_list(Request $request)
    {
        $selectedMenu   = 'Outlet pay';         // Required Variable
        $pageTitle      = 'Payment List';       // Required Variable
        
        
        $this->outlet_in_charge  = Auth::user()->id;
        $this->user_type_id     = Auth::user()->user_type_id;
        
        $fromdate   = date('Y-m-d', strtotime($request->get('fromdate')));
        $todate     = date('Y-m-d', strtotime($request->get('todate')));
        $customer   = $request->get('customer');
        $payment_type   = $request->get('payment_type');

        //dd($customer);

        $outletList = DB::table('mts_customer_list')
                            ->orderBy('customer_id','asc')
                            ->get();
        
        $user_business_type=DB::select("select * from users where id='".$this->outlet_in_charge."'");
        
        foreach ($user_business_type as $type)
        {

            $user_type=$type->business_type_id;
            $outlet_name=$type->display_name;

        }
        
        if($fromdate!='' && $todate!='' && $customer=='' && $payment_type=='')
        {
 

            $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id') 
                       ->where('mts_outlet_payments.ack_status','APPROVE')
                       ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))  
                        ->get();


        }
        elseif($fromdate!='' && $todate!='' && $customer!='' && $payment_type=='')
        {

            $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id') 
                       ->where('mts_outlet_payments.ack_status','APPROVE')
                       ->where('mts_outlet_payments.customer_id',$customer)
                       ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))  
                        ->get(); 


        }
        elseif($fromdate!='' && $todate!='' && $customer!='' && $payment_type!='')
        {
            $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id') 
                       ->where('mts_outlet_payments.ack_status','APPROVE')
                       ->where('mts_outlet_payments.customer_id',$customer)
                       ->where('mts_outlet_payments.payment_type',$payment_type)
                       ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))  
                        ->get();  

        }
        elseif($fromdate!='' && $todate!='' && $customer=='' && $payment_type!='')
        {
            $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id') 
                       ->where('mts_outlet_payments.ack_status','APPROVE')
                       ->where('mts_outlet_payments.payment_type',$payment_type)
                       ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))  
                        ->get();  

        }

        return view('ModernSales::payment/account/outlet_credit_list')->with('outletList',$outletList)
        ->with('outletPayment',$outletPayment)
        ->with('user_business_type',$user_type)
        ->with('outlet_name',$outlet_name)
        ->with('selectedMenu',$selectedMenu)
        ->with('pageTitle',$pageTitle);

    }
    public function account_payment_receive(Request $request)
    {

        $id = $request->get('id');
        $net_amount = $request->get('net_amount');
        $bank_charge = $request->get('bank_charge');

//dd($id);
        DB::table('mts_outlet_payments')->where('transaction_id', $id)->update(
            [
                'net_amount'           => $net_amount,
                'bank_charge'          => $bank_charge,
                'receive_by'           => Auth::user()->id,
                'receive_date'         => date('Y-m-d'),
                'ack_status'           => 'CONFIRMED'
            ]
        );

        $payments = DB::table('mts_outlet_payments')
        ->join('mts_customer_list', 'mts_customer_list.customer_id', 'mts_outlet_payments.customer_id')
        ->where('transaction_id', $id)->first();

        
        if($payments->payment_amount>0){

            $ledger = DB::table('mts_outlet_ledger')->where('customer_id', $payments->customer_id)->orderBy('ledger_id','DESC')->first();

            
            if(sizeof($ledger)){
                $closing_balance = $ledger->closing_balance;
            }else{
                $closing_balance = 0;
            }
            DB::table('mts_outlet_ledger')->insert(
                [
                    'ledger_date'           => date('Y-m-d h:i:s'),
                    'customer_id'           => $payments->customer_id,
                    'party_sap_code'        => $payments->sap_code,
                    'trans_type'            => 'payment',
                    'opening_balance'       => $closing_balance,
                    'debit'                 => 0,
                    'credit'                => $payments->payment_amount,
                    'closing_balance'       => $closing_balance-$payments->payment_amount,
                    'entry_by'              => Auth::user()->id,
                    'entry_date'            => date('Y-m-d h:i:s')

                ]
            );
        }

        if($payments->adjust_amount>0){

            $ledger = DB::table('mts_outlet_ledger')->where('customer_id', $payments->customer_id)->orderBy('ledger_id','DESC')->first();

             
            if(sizeof($ledger)){
                $closing_balance = $ledger->closing_balance;
            }else{
                $closing_balance = 0;
            }
            DB::table('mts_outlet_ledger')->insert(
                [
                    'ledger_date'           => date('Y-m-d h:i:s'),
                    'customer_id'           => $payments->customer_id,
                    'party_sap_code'        => $payments->sap_code,
                    'trans_type'            => 'adjustment',
                    'opening_balance'       => $closing_balance,
                    'debit'                 => 0,
                    'credit'                => $payments->adjust_amount,
                    'closing_balance'       => $closing_balance-$payments->adjust_amount,
                    'entry_by'              => Auth::user()->id,
                    'entry_date'            => date('Y-m-d h:i:s'),
                    'is_adjustment'         => 1

                ]
            );
        }

        
        
        return Redirect::to('/accounts_payments_con')->with('success', 'Successfully Payment Added.');

    }

    public function accounts_payments_rece_report()
    {
        $selectedMenu   = 'Outlet report';         // Required Variable
        $pageTitle      = 'Payment List';       // Required Variable
        
        
        $this->outlet_in_charge  = Auth::user()->id;
        $this->user_type_id     = Auth::user()->user_type_id;

        $outletList = DB::table('mts_customer_list')
                            ->orderBy('customer_id','asc')
                            ->get();
        
        
        $user_business_type=DB::select("select * from users where id='".$this->outlet_in_charge."'");
        
        foreach ($user_business_type as $type)
        {

            $user_type=$type->business_type_id;
            $outlet_name=$type->display_name;

        }

 
        $outletList = DB::table('mts_customer_list')
                            ->orderBy('customer_id','asc')
                            ->get();
         $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id') 
                       ->where('mts_outlet_payments.ack_status','CONFIRMED')
                       ->get();

        


        return view('ModernSales::payment/account/report/outlet_credit')->with('outletList',$outletList)
        ->with('outletPayment',$outletPayment)
        ->with('user_business_type',$user_type)
        ->with('outlet_name',$outlet_name)
        ->with('selectedMenu',$selectedMenu)
        ->with('pageTitle',$pageTitle);

    }
    

    public function accounts_payments_rece_report_list(Request $request)
    {
        $selectedMenu   = 'Outlet report';         // Required Variable
        $pageTitle      = 'Payment List';       // Required Variable
        
        
        $this->outlet_in_charge  = Auth::user()->id;
        $this->user_type_id     = Auth::user()->user_type_id;
         
        $fromdate   = date('Y-m-d', strtotime($request->get('fromdate')));
        $todate     = date('Y-m-d', strtotime($request->get('todate')));
        $customer   = $request->get('customer');
        $payment_type   = $request->get('payment_type');
        
        $outletList = DB::table('mts_customer_list')
                            ->orderBy('customer_id','asc')
                            ->get();
        
        $user_business_type=DB::select("select * from users where id='".$this->outlet_in_charge."'");
        
        foreach ($user_business_type as $type)
        {

            $user_type=$type->business_type_id;
            $outlet_name=$type->display_name;

        }

        if($fromdate!='' && $todate!='' && $customer=='' && $payment_type=='')
        {
 

            $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id') 
                       ->where('mts_outlet_payments.ack_status','CONFIRMED')
                       ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))  
                        ->get();


        }
        elseif($fromdate!='' && $todate!='' && $customer!='' && $payment_type=='')
        {

            $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id') 
                       ->where('mts_outlet_payments.ack_status','CONFIRMED')
                       ->where('mts_outlet_payments.customer_id',$customer)
                       ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))  
                        ->get(); 


        }
        elseif($fromdate!='' && $todate!='' && $customer!='' && $payment_type!='')
        {
            $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id') 
                       ->where('mts_outlet_payments.ack_status','CONFIRMED')
                       ->where('mts_outlet_payments.customer_id',$customer)
                       ->where('mts_outlet_payments.payment_type',$payment_type)
                       ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))  
                        ->get();  

        }
        elseif($fromdate!='' && $todate!='' && $customer=='' && $payment_type!='')
        {
            $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id') 
                       ->where('mts_outlet_payments.ack_status','CONFIRMED')
                       ->where('mts_outlet_payments.payment_type',$payment_type)
                       ->whereBetween(DB::raw("(DATE_FORMAT(mts_outlet_payments.trans_date,'%Y-%m-%d'))"), array($fromdate, $todate))  
                        ->get();  

        }
        

        return view('ModernSales::payment/account/report/outlet_credit_list')->with('outletList',$outletList)
        ->with('outletPayment',$outletPayment)
        ->with('user_business_type',$user_type)
        ->with('outlet_name',$outlet_name)
        ->with('selectedMenu',$selectedMenu)
        ->with('pageTitle',$pageTitle);

    }

    public function app_admin_payment_edit(Request $request)
    {
 
        $selectedMenu   = 'Outlet report';         // Required Variable
        $pageTitle      = 'Payment List';       // Required Variable

         $outletList = DB::table('mts_customer_list') 
                        ->join('mts_customer_define_executive', 'mts_customer_define_executive.customer_id', '=', 'mts_customer_list.customer_id')
                        ->where('mts_customer_list.status',0)
                        ->orderBy('mts_customer_list.name','ASC')    
                        ->get();

        $bankList = DB::table('tbl_master_bank')
                        ->where('status',0)
                        ->orderBy('bank_name','asc')
                        ->get();

       $outletPayment= DB::table('mts_outlet_payments')
                       ->JOIN('mts_customer_list','mts_customer_list.customer_id','mts_outlet_payments.customer_id')
                       ->leftjoin('tbl_master_bank','tbl_master_bank.id','=','mts_outlet_payments.bank_info_id')
                       ->where('transaction_id', $request->get('paymentid'))->first();

       // dd($request->get('paymentid'));
        
        return view('ModernSales::payment/admin/editPayment')
        ->with('selectedMenu',$selectedMenu)
        ->with('pageTitle',$pageTitle)
        ->with('outletList',$outletList)
        ->with('bankList',$bankList)
        ->with('outletPayment',$outletPayment);
    }
    public function app_admin_payment_edit_submit(Request $request)
    { 

        DB::table('mts_outlet_payments')->where('transaction_id', $request->get('id'))->update(
            [
                'customer_id'               => $request->customer_id,
                'payment_type'              => $request->payment_type,
                'bank_info_id'              => $request->bank_info,
                'branch_name'               => $request->branch_name,
                'ref_no'                    => $request->ref_no,
                'cheque_date'               => $request->cheque_date, 
                'payment_amount'            => $request->payment_amount,
                'adjust_amount'             => $request->adjust_amount,
                'payment_remarks'           => $request->payment_remarks,
                'update_by'                 => Auth::user()->id,
                'update_date'               => date('Y-m-d')
            ]
        );
        return Redirect::to('/admin_payments_con')->with('success', 'Successfully Payment Update.');

        
    }
    
} 