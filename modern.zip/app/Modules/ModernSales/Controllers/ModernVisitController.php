<?php

namespace App\Modules\ModernSales\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Redirect;

use DB;
use Auth;
use Session;

class ModernVisitController extends Controller
{
    /*public function __construct()
    {
       $this->middleware('auth'); // for auth check       
    }
*/

    public function mts_visit()
    {

        $selectedMenu   = 'Visit';         // Required Variable
        $pageTitle      = 'Visit';        // Page Slug Title

         $routeResult = DB::table('mts_route')
                        ->where('status',0)
                        ->get();

         $customerResult = DB::table('mts_customer_list') 
                        ->join('mts_customer_define_executive', 'mts_customer_define_executive.customer_id', '=', 'mts_customer_list.customer_id')
                        ->where('mts_customer_define_executive.executive_id', Auth::user()->id)
                        ->where('mts_customer_list.status',0)
                        ->orderBy('mts_customer_list.name','ASC')    
                        ->get();
      

        return view('ModernSales::sales/visitManage', compact('selectedMenu','pageTitle','routeResult','resultRetailer','customerResult'));
    }

     public function mts_partyList(Request $request)
    {

        $customerID = $request->get('customer');

        $resultParty = DB::table('mts_party_list')
                        ->select('party_id','name','customer_id','owner','address','status')
                        ->where('global_company_id', Auth::user()->global_company_id)
                        ->where('customer_id', $customerID)
                        ->where('status', 0)
                        ->orderBy('name','ASC')                    
                        ->get();
      

        return view('ModernSales::sales/partyList', compact('resultParty','customerID'));
    }

    public function mts_order_process($partyid,$customer_id)
    {
        $selectedMenu   = 'Visit';             // Required Variable
        $pageTitle      = 'New Order';        // Page Slug Title

        

        $resultParty = DB::table('mts_party_list')
                        ->select('party_id','name','route_id','customer_id','owner','address','status')
                        ->where('global_company_id', Auth::user()->global_company_id)
                        ->where('customer_id', $customer_id)                       
                        ->where('party_id', $partyid)
                        ->where('status', 0)
                        ->first();
        
        $resultCategory = DB::table('tbl_product_category')
                        ->select('id','status','LAF','name','g_name','g_code','avg_price','global_company_id')
                        ->where('status', '0')
                        ->where('global_company_id', Auth::user()->global_company_id)
                        ->get();
       

        $resultCart     = DB::table('mts_order')                     
                        ->where('fo_id',Auth::user()->id)                        
                        ->where('party_id',$partyid) 
                        ->Where('order_status', 'Ordered')                       
                        ->first();  

        
        
        return view('ModernSales::sales/categoryWithOrder', 
        compact('selectedMenu','pageTitle','resultParty','resultCategory','partyid','customer_id','resultCart'));
    }

    public function mts_category_products(Request $request)
    {
        $categoryID = $request->get('categories');
        $party_id     = $request->get('retailer_id');

        $resultProduct = DB::table('tbl_product')
                        ->select('id','category_id','name','ims_stat','status','depo AS price','unit','sap_code')
                        ->where('ims_stat', '0')                       
                        ->where('category_id', $categoryID)
                        ->orderBy('id', 'ASC')
                        ->orderBy('status', 'ASC')
                        ->orderBy('name', 'ASC')
                        ->get();

        $lastDiscount = DB::table('mts_categroy_wise_commission')        
                        ->where('party_id', $party_id)
                        ->where('cat_id', $categoryID)
                        ->orderBy('id', 'desc') 
                        ->first();

        return view('ModernSales::sales/allProductList', compact('resultProduct','categoryID','party_id','lastDiscount'));
    }


     public function mts_add_to_cart_products(Request $request)
    {
        
        $customerResult = DB::table('mts_customer_list') 
                        ->where('customer_id',$request->get('customer_id'))
                        ->where('status',0)
                        ->first();

        if(sizeof($customerResult) > 0)
        {
            $sap_code = $customerResult->sap_code;
        }
        else
        {
            $sap_code = 0;
        }

        $autoOrder = DB::table('mts_order')->select('auto_order_no')->orderBy('order_id','DESC')->first();
    
        if(sizeof($autoOrder) > 0)
        {
            $autoOrderId = $autoOrder->auto_order_no + 1;
        }
        else
        {
            $autoOrderId = 1000;
        }    

        $currentYear    = substr(date("Y"), -2); // 2017 to 17
        $currentMonth   = date("m");            // 12
        $currentDay     = date("d");           // 14
        $retailerID     = $request->get('retailer_id');

        $orderNo        = 'SO'.'-'.$sap_code.'-'.$currentYear.$currentMonth.$currentDay.'-'.$autoOrderId;


        $totalQty   = $request->get('totalQty');
        $totalValue = $request->get('totalValue');


        $countRows = count($request->get('qty'));

        $resultCart     = DB::table('mts_order')
                        ->where('order_status', 'Ordered')                        
                        ->where('fo_id',Auth::user()->id)                        
                        ->where('party_id',$retailerID)
                        ->orderBy('order_id','DESC')                         
                        ->first(); 

        $supervisorList = DB::table('mts_role_hierarchy')
                        ->where('status',0)                        
                        ->where('officer_id',Auth::user()->id) 
                        ->first();

        //dd($supervisorList);

        if(sizeof($resultCart)> 0) 
        {

         $checkOrder     = DB::table('mts_order_details')
                        ->where('order_id', $resultCart->order_id)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$retailerID)                        
                        ->where('cat_id',$request->get('cat_id'))                        
                        ->delete(); 

         $checkCommission     = DB::table('mts_categroy_wise_commission')
                        ->where('order_id', $resultCart->order_id)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$retailerID)                        
                        ->where('cat_id',$request->get('cat_id'))                        
                        ->delete();
 
        }

        if(sizeof($resultCart)== 0) 
        {
           
            DB::table('mts_order')->insert(
                [
                    'order_no'              => $orderNo,
                    'auto_order_no'         => $autoOrderId,
                    'order_date'            => date('Y-m-d h:i:s'),
                    'order_status'          => 'Ordered',
                    'total_order_qty'       => $totalQty,
                    'total_order_value'     => $totalValue,
                    'customer_id'           => $request->get('customer_id'),
                    'party_id'              => $request->get('retailer_id'),
                    'management_id'         => $supervisorList->management_id,
                    'manager_id'            => $supervisorList->manager_id,
                    'executive_id'          => $supervisorList->executive_id,
                    'fo_id'                 => Auth::user()->id,
                    'global_company_id'     => Auth::user()->global_company_id,
                    'entry_by'              => Auth::user()->id,
                    'entry_date'            => date('Y-m-d h:i:s')
                    
                ]
            );

           $resultCart     = DB::table('mts_order')
                        ->where('order_status', 'Ordered')                        
                        ->where('fo_id',Auth::user()->id)                        
                        ->where('party_id',$retailerID)
                        ->orderBy('order_id','DESC')                         
                        ->first(); 
           

            for($m=0;$m<$countRows;$m++)
            {
                if($request->get('qty')[$m]!='')
                {
                    $totalPrice = $request->get('qty')[$m] * $request->get('price')[$m];


                    DB::table('mts_order_details')->insert(
                        [
                            'order_id'          => $resultCart->order_id,
                            'order_date'        => date('Y-m-d H:i:s'),
                            'cat_id'            => $request->get('category_id')[$m],
                            'product_id'        => $request->get('produuct_id')[$m],
                            'order_qty'         => $request->get('qty')[$m],
                            'p_unit_price'      => $request->get('price')[$m],
                            'order_total_value' => $totalPrice,
                            'order_det_status'  => 'Ordered',
                            'discount_rate'     => $request->get('commission'),
                            'party_id'          => $retailerID,
                            'entry_by'          => Auth::user()->id,
                            'entry_date'        => date('Y-m-d h:i:s')

                        ]
                    );

                }

            }
         }else{ 

            for($m=0;$m<$countRows;$m++)
            {
                if($request->get('qty')[$m]!='')
                {
                    $totalPrice = $request->get('qty')[$m] * $request->get('price')[$m];


                    DB::table('mts_order_details')->insert(
                        [
                            'order_id'          => $resultCart->order_id,
                            'order_date'        => date('Y-m-d H:i:s'),
                            'cat_id'            => $request->get('category_id')[$m],
                            'product_id'        => $request->get('produuct_id')[$m],
                            'order_qty'         => $request->get('qty')[$m],
                            'p_unit_price'      => $request->get('price')[$m],
                            'order_total_value' => $totalPrice,
                            'order_det_status'  => 'Ordered',
                            'discount_rate'     => $request->get('commission'),
                            'party_id'          => $retailerID,
                            'entry_by'          => Auth::user()->id,
                            'entry_date'        => date('Y-m-d h:i:s')

                        ]
                    );

                }

            }


            $totalOrder = DB::table('mts_order_details')
                        ->select(DB::raw('SUM(order_qty) AS totalQty'), DB::raw('SUM(order_total_value) AS totalValue'))
                        ->where('order_id', $resultCart->order_id)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$retailerID)
                        ->first();

             DB::table('mts_order')->where('order_id', $resultCart->order_id)                        
                ->where('entry_by',Auth::user()->id)                        
                ->where('party_id',$retailerID)->update(
                [
                    'total_order_qty'       => $totalOrder->totalQty,
                    'total_order_value'     => $totalOrder->totalValue,
                    'entry_date'            => date('Y-m-d h:i:s')
                    
                ]
            );

           
         }

            if(sizeof($request->get('commission'))>0){
                $commissionValue = ($totalValue * $request->get('commission'))/100;
                
                DB::table('mts_categroy_wise_commission')->insert(
                    [
                        'order_id'              => $resultCart->order_id,
                        'cat_id'                => $request->get('cat_id'),
                        'customer_id'           => $request->get('customer_id'),
                        'party_id'              => $request->get('retailer_id'),
                        'fo_id'                 => Auth::user()->id,
                        'order_value'           => $totalValue, 
                        'order_commission_value'=> $commissionValue,
                        'commission'            => $request->get('commission'),
                        'global_company_id'     => Auth::user()->global_company_id,
                        'entry_by'              => Auth::user()->id,
                        'entry_date'            => date('Y-m-d h:i:s')
                    ]
                );
            }
           
            return Redirect::to('/mts-order-process/'.$request->get('retailer_id').'/'.$request->get('customer_id'))->with('success', 'Successfully Added Add To Cart.');
        

    }

    public function mts_bucket($customer_id,$partyid)
    {


        $selectedMenu   = 'Visit';             // Required Variable
        $pageTitle      = 'Bucket';           // Page Slug Title 

        $resultFoInfo   = DB::table('users')
                        ->select('users.id','users.email','tbl_user_type.user_type','tbl_user_business_scope.point_id','tbl_user_business_scope.division_id')
                         ->join('tbl_user_type', 'users.user_type_id', '=', 'tbl_user_type.user_type_id')
                         ->join('tbl_user_business_scope', 'tbl_user_business_scope.user_id', '=', 'users.id')
                         ->join('tbl_global_company', 'tbl_global_company.global_company_id', '=', 'users.global_company_id')
                         ->where('tbl_user_type.user_type_id', 12)
                         ->where('users.id', Auth::user()->id)
                         ->where('users.is_active', 0) // 0 for active
                         ->where('tbl_user_business_scope.is_active', 0) 
                         ->where('tbl_global_company.global_company_id', Auth::user()->global_company_id)
                         ->first(); 

       
         $resultCartPro  = DB::table('mts_order_details')
                        ->select('mts_order_details.cat_id','mts_order_details.order_id','tbl_product_category.id AS catid',
                        'tbl_product_category.name AS catname','mts_order.order_id','mts_order.fo_id','mts_order.order_status',
                        'mts_order.order_no','mts_order.po_no','mts_order.party_id','mts_order_details.order_date') 
                        ->join('tbl_product_category', 'tbl_product_category.id', '=', 'mts_order_details.cat_id') 
                        ->join('mts_order', 'mts_order.order_id', '=', 'mts_order_details.order_id')
                        ->where('mts_order.order_status','Ordered')                        
                        ->where('mts_order.fo_id',Auth::user()->id)                        
                        ->where('mts_order.party_id',$partyid)
                        ->groupBy('mts_order_details.cat_id')                        
                        ->get();


            $resultInvoice  = DB::table('mts_order')->select('order_id','po_no','order_status','fo_id','party_id','total_order_value')
                        ->where('order_status', 'Ordered')                        
                        ->where('fo_id',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->first();

            $orderCommission = DB::table('mts_categroy_wise_commission') 
                        ->select('order_id','party_id',DB::raw('SUM(order_commission_value) AS commission'),'entry_by')
                        ->where('order_id', $resultInvoice->order_id)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->first();

            $customerResult = DB::table('mts_customer_list')
                        ->where('customer_id',$customer_id)
                        ->where('status',0)
                        ->first();

             $closingResult = DB::table('mts_outlet_ledger')
                        ->where('customer_id',$customer_id)
                        ->orderBy('ledger_id','DESC')
                        ->first();

            if(sizeof($closingResult)>0){
                $closingBalance = $closingResult->closing_balance;
            } else{
                $closingBalance = 0;
            } 

           $creditSummery = $customerResult->credit_limit - $closingBalance - $resultInvoice->total_order_value;        

            //echo $closingBalance;


        return view('ModernSales::sales/bucket',compact('selectedMenu','pageTitle','partyid','customer_id','resultCartPro','resultInvoice','orderCommission','creditSummery'));
   

    }

    public function mts_items_edit(Request $request)
    {

        $partyid        = $request->get('partyid');
        $customer_id    = $request->get('customer_id');
        $catid          = $request->get('catid');
        $orderid          = $request->get('orderid');

        
        $resultPro  = DB::table('mts_order_details')
                        ->select('mts_order_details.order_det_id','mts_order_details.order_id','mts_order_details.product_id',
                        'mts_order_details.order_qty','mts_order_details.order_qty',
                        'mts_order_details.p_unit_price','tbl_product.name','tbl_product.sap_code')
                        ->join('tbl_product', 'tbl_product.id', '=', 'mts_order_details.product_id')
                        ->where('mts_order_details.order_det_id', $request->get('itemsid'))
                        ->first();

        $checkCommission     = DB::table('mts_categroy_wise_commission')
                                ->where('order_id', $orderid)                        
                                ->where('entry_by',Auth::user()->id)                        
                                ->where('party_id',$partyid)                        
                                ->where('cat_id',$catid)
                                ->first();

        //dd($checkCommission);

        $resultCatDefault  = DB::table('tbl_product_category')
                        ->select('id')                        
                        ->where('id', $request->get('catid'))
                        ->first();

        return view('ModernSales::sales/editItems', compact('resultPro','partyid','customer_id','catid','resultCatDefault','checkCommission'));
    }


    public function mts_items_edit_submit(Request $request)
    {

        $partyid    = $request->get('partyid');
        $customer_id    = $request->get('customer_id');
        $catid      = $request->get('catid');
        $orderid    = $request->get('orderid');
        
        $price          = $request->get('items_qty') * $request->get('items_price');
        
        DB::table('mts_order_details')->where('order_det_id',$request->get('id'))->update(
            [
                'order_qty'         => $request->get('items_qty'), 
                'order_total_value' => $price, 
                'order_date'        => date('Y-m-d H:i:s') 
            ]
        ); 

        DB::table('mts_order_details')->where('order_id',$orderid)->where('cat_id',$catid)->update(
            [
                'discount_rate'         => $request->get('commission') 
            ]
        );     

        $totalOrder = DB::table('mts_order_details') 
                        ->select(DB::raw('SUM(order_qty) AS totalQty'), DB::raw('SUM(order_total_value) AS totalValue'))
                        ->where('order_id', $orderid)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->first();
             

        DB::table('mts_order')->where('order_id', $orderid)->where('fo_id', Auth::user()->id)->where('entry_by',Auth::user()->id)->update(
            [ 
                'order_date'            => date('Y-m-d H:i:s'),
                'total_order_qty'       => $totalOrder->totalQty,
                'total_order_value'     => $totalOrder->totalValue,
                'entry_date'            => date('Y-m-d h:i:s')
            ]
        );

        //dd($orderid);
         $checkCommission     = DB::table('mts_categroy_wise_commission')
                                ->where('order_id', $orderid)                        
                                ->where('entry_by',Auth::user()->id)                        
                                ->where('party_id',$partyid)                        
                                ->where('cat_id',$catid)                        
                                ->delete();  

        $totalOrder = DB::table('mts_order_details')
                        ->select(DB::raw('SUM(order_qty) AS totalQty'), DB::raw('SUM(order_total_value) AS totalValue'))
                        ->where('order_id', $orderid)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->where('cat_id',$catid)
                        ->first();  

        $totalValue = $totalOrder->totalValue;
        if(sizeof($request->get('commission'))>0){
                $commissionValue = ($totalValue * $request->get('commission'))/100;
                
                DB::table('mts_categroy_wise_commission')->insert(
                    [
                        'order_id'              => $orderid,
                        'cat_id'                => $catid,
                        'customer_id'           => $customer_id,
                        'party_id'              => $partyid,
                        'fo_id'                 => Auth::user()->id,
                        'order_value'           => $totalValue, 
                        'order_commission_value'=> $commissionValue,
                        'commission'            => $request->get('commission'),
                        'global_company_id'     => Auth::user()->global_company_id,
                        'entry_by'              => Auth::user()->id,
                        'entry_date'            => date('Y-m-d h:i:s')
                    ]
                );
            }          

        return Redirect::back()->with('success', 'Successfully Updated Order Product.');

    }


    public function mts_items_delete($orderid,$itemid,$customer_id,$partyid,$catid){

        
        $checkCommission     = DB::table('mts_categroy_wise_commission')
                                ->where('order_id', $orderid)                        
                                ->where('entry_by',Auth::user()->id)                        
                                ->where('party_id',$partyid)                        
                                ->where('cat_id',$catid)                        
                                ->delete(); 

        $totalOrder = DB::table('mts_order_details')
                        ->select('order_det_id','order_id','party_id','cat_id','product_id','discount_rate','entry_by',DB::raw('SUM(order_qty) AS totalQty'), DB::raw('SUM(order_total_value) AS totalValue'))
                        ->where('order_id', $orderid)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->where('cat_id',$catid)
                        ->where('order_det_id','!=',$itemid)
                        ->first();

       
        if(sizeof($totalOrder)>0){

            $totalValue = $totalOrder->totalValue;
            $discount = $totalOrder->discount_rate;
            $commissionValue = ($totalValue *  $discount)/100;
            
            DB::table('mts_categroy_wise_commission')->insert(
                [
                    'order_id'              => $orderid,
                    'cat_id'                => $catid,
                    'customer_id'           => $customer_id,
                    'party_id'              => $partyid,
                    'fo_id'                 => Auth::user()->id,
                    'order_value'           => $totalValue, 
                    'order_commission_value'=> $commissionValue,
                    'commission'            => $discount,
                    'global_company_id'     => Auth::user()->global_company_id,
                    'entry_by'              => Auth::user()->id,
                    'entry_date'            => date('Y-m-d h:i:s')
                ]
            );
        } 

        $itemdelete = DB::table('mts_order_details')
                        ->where('order_id', $orderid)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->where('cat_id',$catid)
                        ->where('order_det_id',$itemid)
                        ->delete(); 

        $totalOrder = DB::table('mts_order_details')

                        ->select(DB::raw('SUM(order_qty) AS totalQty'), DB::raw('SUM(order_total_value) AS totalValue'))
                        ->where('order_id', $orderid)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->first();
             

        DB::table('mts_order')->where('order_id', $orderid)->where('fo_id', Auth::user()->id)->where('entry_by',Auth::user()->id)->update(
            [ 
                'order_date'            => date('Y-m-d H:i:s'),
                'total_order_qty'       => $totalOrder->totalQty,
                'total_order_value'     => $totalOrder->totalValue,
                'entry_date'            => date('Y-m-d h:i:s')
            ]
        );
          

         return Redirect::back()->with('success', 'Successfully Delete Product.');
    }

    public function mts_confirm_order(Request $request)
    {

        $orderid    = $request->get('orderid');
        $partyid    = $request->get('partyid');
        $customer_id    = $request->get('customer_id');
        $po_no      = $request->get('po_no');

        //dd($po_no);

        $totalOrder = DB::table('mts_order_details')
                        ->select(DB::raw('SUM(order_qty) AS totalQty'), DB::raw('SUM(order_total_value) AS totalValue'))
                        ->where('order_id', $orderid)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->first();
             

        DB::table('mts_order')->where('order_id', $orderid)->where('fo_id', Auth::user()->id)->where('entry_by',Auth::user()->id)->update(
            [
                'po_no'                 => $po_no, 
                'order_status'          => 'Confirmed',
                'ack_status'            => 'Pending',  
                'order_date'            => date('Y-m-d H:i:s'),
                'total_order_qty'       => $totalOrder->totalQty,
                'total_order_value'     => $totalOrder->totalValue,
                'entry_date'            => date('Y-m-d h:i:s')
            ]
        );

        DB::table('mts_order_details')
                ->where('order_id', $orderid)
                ->update(
                    [
                        'order_det_status'          => 'Confirmed'
                    ]
            );




    return Redirect::to('/mts-visit')->with('success', 'Successfully Confirmed Order');

    }


    public function mts_delete_order($orderid,$partyid,$customer_id)
    {
        $checkCommission     = DB::table('mts_categroy_wise_commission')
                                ->where('order_id', $orderid)                        
                                ->where('entry_by',Auth::user()->id)                        
                                ->where('party_id',$partyid)                     
                                ->delete(); 

        $totalOrder = DB::table('mts_order_details')
                        ->where('order_id', $orderid)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->delete();

         $totalOrder = DB::table('mts_order')
                        ->where('order_id', $orderid)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->delete();




    return Redirect::to('/mts-visit')->with('success', 'Successfully Delete Order');

    }



   public function mts_order_not_approve()
    {
        $selectedMenu   = 'Order Not approve';                      // Required Variable for menu
        $selectedSubMenu= 'Order Not approve';                    // Required Variable for submenu
        $pageTitle      = 'Order Not approve';            // Page Slug Title
        //dd(Auth::user()->id);
        $resultFO       = DB::table('mts_order')
        ->select('mts_order.global_company_id','mts_order.order_status','mts_order.order_id','mts_order.fo_id','tbl_user_details.user_id','users.display_name','users.email','tbl_user_details.first_name','tbl_user_details.middle_name','tbl_user_details.last_name')
        ->join('users', 'users.id', '=', 'mts_order.fo_id')
        ->join('tbl_user_details', 'tbl_user_details.user_id', '=', 'users.id')
        ->where('mts_order.order_status', 'Ordered')
        ->where('mts_order.ack_status', 'Rejected')
        ->where('mts_order.global_company_id', Auth::user()->global_company_id)
        ->where('mts_order.fo_id', Auth::user()->id)
        ->groupBy('mts_order.fo_id')
        ->orderBy('mts_order.order_id','DESC')                    
        ->get();


        $todate     = date('Y-m-d');
         $resultOrderList = DB::table('mts_order')
            ->select('mts_order.*','tbl_user_details.user_id','users.display_name','users.email','tbl_user_details.first_name','tbl_user_details.middle_name','tbl_user_details.last_name','mts_party_list.name','mts_party_list.mobile','mts_party_list.address')
            ->join('users', 'users.id', '=', 'mts_order.fo_id')
            ->join('tbl_user_details', 'tbl_user_details.user_id', '=', 'users.id')
            ->join('mts_party_list', 'mts_party_list.party_id', '=', 'mts_order.party_id')
            ->where('mts_order.order_status', 'Ordered')
            ->where('mts_order.ack_status', 'Rejected')
            ->where('mts_order.global_company_id', Auth::user()->global_company_id)
            ->where('mts_order.fo_id', Auth::user()->id)
            ->whereBetween(DB::raw("(DATE_FORMAT(mts_order.order_date,'%Y-%m-%d'))"), array($todate, $todate))
            ->orderBy('mts_order.order_id','DESC')                    
            ->get();
  
        return view('ModernSales::sales/orderNotApprove', compact('selectedMenu','selectedSubMenu','pageTitle','resultFO','resultOrderList'));
    }

    public function mts_order_not_approve_list(Request $request)
    {
        $fromdate   = date('Y-m-d', strtotime($request->get('fromdate')));
        $todate     = date('Y-m-d', strtotime($request->get('todate')));

        if($fromdate!='' && $todate!='' && $request->get('fos')=='')
        {
            $resultOrderList = DB::table('mts_order')
            ->select('mts_order.*','tbl_user_details.user_id','users.display_name','users.email','tbl_user_details.first_name','tbl_user_details.middle_name','tbl_user_details.last_name','mts_party_list.name','mts_party_list.mobile','mts_party_list.address')
            ->join('users', 'users.id', '=', 'mts_order.fo_id')
            ->join('tbl_user_details', 'tbl_user_details.user_id', '=', 'users.id')
            ->join('mts_party_list', 'mts_party_list.party_id', '=', 'mts_order.party_id')
            ->where('mts_order.order_status', 'Ordered')
            ->where('mts_order.ack_status', 'Rejected')
            ->where('mts_order.global_company_id', Auth::user()->global_company_id)
            ->where('mts_order.fo_id', Auth::user()->id)
            ->whereBetween(DB::raw("(DATE_FORMAT(mts_order.order_date,'%Y-%m-%d'))"), array($fromdate, $todate))
            ->orderBy('mts_order.order_id','DESC')                    
            ->get();
        }
        else
        {
            $resultOrderList = DB::table('mts_order')
            ->select('mts_order.*','tbl_user_details.user_id','users.display_name','users.email','tbl_user_details.first_name','tbl_user_details.middle_name','tbl_user_details.last_name','mts_party_list.name','mts_party_list.mobile','mts_party_list.address')
            ->join('users', 'users.id', '=', 'mts_order.fo_id')
            ->join('tbl_user_details', 'tbl_user_details.user_id', '=', 'users.id')
            ->join('mts_party_list', 'mts_party_list.party_id', '=', 'mts_order.party_id')
            ->where('mts_order.order_status', 'Ordered')
            ->where('mts_order.ack_status', 'Rejected')
            ->where('mts_order.global_company_id', Auth::user()->global_company_id)
            ->where('mts_order.fo_id', Auth::user()->id)
            ->whereBetween(DB::raw("(DATE_FORMAT(mts_order.order_date,'%Y-%m-%d'))"), array($fromdate, $todate))
            ->orderBy('mts_order.order_id','DESC')                    
            ->get();
        }
        
        return view('ModernSales::sales/orderNotApproveList', compact('resultOrderList'));
    }
}
