<?php

namespace App\Models\Sales;

use Illuminate\Database\Eloquent\Model;

class SpecialOfferSkuModel extends Model
{
    protected $table = 'tbl_special_sku_products';
}
