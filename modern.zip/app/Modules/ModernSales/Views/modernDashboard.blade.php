@extends('ModernSales::masterPage')
@section('content')
<section class="content">
	<div class="row clearfix">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="card" style="font-weight:">
				<div class="body" id="printMe" >


				</div>

				
			</div>
		</div>
	</div>
	<!-- #END# Basic Validation -->            
</div>
</section>
@endsection