<select  class="form-control show-tick" name="fos" id="fos">
	<option value="">Select Officer</option>
	@foreach($officerlist as $row)
		<option value="{{ $row->id }}">{{ $row->display_name }}</option>
	@endforeach 
</select>


