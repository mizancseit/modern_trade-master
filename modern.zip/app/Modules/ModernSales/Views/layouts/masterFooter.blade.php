{{-- Master Footer  --}}

<div class="legal">
	<div class="copyright">
		&copy; {{ date('Y') }} <a href="javascript:void(0);">Modern Trade</a>
	</div>
	<div class="version">
		<b>Version: </b> 1.0
	</div>
</div>