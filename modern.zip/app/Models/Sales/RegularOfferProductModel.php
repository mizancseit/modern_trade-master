<?php

namespace App\Models\sales;

use Illuminate\Database\Eloquent\Model;

class RegularOfferProductModel extends Model
{
    protected $table = 'tbl_regular_offer_product';
   /* protected $fillable = ['businessOwnerName', 'businessName', 'email', 'password', 'businessPhone', 'businessStatus', 'businessAgreeStatus', 'created_at']; */
}
