<?php

namespace App\Modules\ModernSales\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Redirect;

use DB;
use Auth;
use Session;

class ModernVisitController extends Controller
{
    /*public function __construct()
    {
       $this->middleware('auth'); // for auth check       
    }
*/

    public function mts_visit()
    {

        $selectedMenu   = 'Visit';         // Required Variable
        $pageTitle      = 'Visit';        // Page Slug Title

         $routeResult = DB::table('mts_route')
                        ->where('status',0)
                        ->get();
      

        return view('ModernSales::sales/visitManage', compact('selectedMenu','pageTitle','routeResult','resultRetailer','routeID'));
    }

     public function mts_partyList(Request $request)
    {

        $routeID = $request->get('route');

        $resultParty = DB::table('mts_party_list')
                        ->select('party_id','name','route_id','owner','address','status')
                        ->where('global_company_id', Auth::user()->global_company_id)                       
                        ->where('route_id', $routeID)
                        ->where('status', 0)
                        ->orderBy('name','ASC')                    
                        ->get();
      

        return view('ModernSales::sales/partyList', compact('resultParty','routeID'));
    }

    public function mts_order_process($partyid,$routeid)
    {
        $selectedMenu   = 'Visit';             // Required Variable
        $pageTitle      = 'New Order';        // Page Slug Title

        

        $resultParty = DB::table('mts_party_list')
                        ->select('party_id','name','route_id','owner','address','status')
                        ->where('global_company_id', Auth::user()->global_company_id)
                        ->where('route_id', $routeid)                       
                        ->where('party_id', $partyid)
                        ->where('status', 0)
                        ->first();
        
        $resultCategory = DB::table('tbl_product_category')
                        ->select('id','status','LAF','name','g_name','g_code','avg_price','global_company_id')
                        ->where('status', '0')
                        ->where('global_company_id', Auth::user()->global_company_id)
                        ->get();
       

        $resultCart     = DB::table('mts_order')                     
                        ->where('fo_id',Auth::user()->id)                        
                        ->where('party_id',$partyid) 
                        ->Where('order_status', 'Ordered')                       
                        ->first();  

        
        
        return view('ModernSales::sales/categoryWithOrder', 
        compact('selectedMenu','pageTitle','resultParty','resultCategory','partyid','routeid','resultCart'));
    }

    public function mts_category_products(Request $request)
    {
        $categoryID = $request->get('categories');
        $party_id     = $request->get('retailer_id');

        $resultProduct = DB::table('tbl_product')
                        ->select('id','category_id','name','ims_stat','status','depo AS price','unit')
                        ->where('ims_stat', '0')                       
                        ->where('category_id', $categoryID)
                        ->orderBy('id', 'ASC')
                        ->orderBy('status', 'ASC')
                        ->orderBy('name', 'ASC')
                        ->get();
       
       /*$lastOrderData   = DB::select("SELECT tbl_order.order_id , tbl_order.order_type, tbl_order.retailer_id, tbl_order.fo_id, tbl_order_details.product_id,
                            tbl_order_details.cat_id, tbl_order_details.order_qty, tbl_order_details.p_total_price, tbl_order_details.p_total_price,
                            tbl_order_details.wastage_qty
                            FROM tbl_order JOIN tbl_order_details ON tbl_order.order_id = tbl_order_details.order_id
                                WHERE  tbl_order.fo_id = '".Auth::user()->id."'
                                and tbl_order.retailer_id = '".$retailerID."'
                                and tbl_order_details.cat_id = '".$categoryID."'
                                and (tbl_order_details.order_qty !='' OR tbl_order_details.wastage_qty !='')
                                and tbl_order.order_type =  'Ordered'
                                order by tbl_order.order_id DESC"); */

       

        return view('ModernSales::sales/allProductList', compact('resultProduct','categoryID','party_id'));
    }


     public function mts_add_to_cart_products(Request $request)
    {
        $autoOrder = DB::table('tbl_order')->select('auto_order_no')->orderBy('order_id','DESC')->first();
    
        if(sizeof($autoOrder) > 0)
        {
            $autoOrderId = $autoOrder->auto_order_no + 1;
        }
        else
        {
            $autoOrderId = 10000;
        }    

        $currentYear    = substr(date("Y"), -2); // 2017 to 17
        $currentMonth   = date("m");            // 12
        $currentDay     = date("d");           // 14
        $retailerID     = $request->get('retailer_id');

        $orderNo        = $retailerID.'-'.$currentYear.$currentMonth.$currentDay.$autoOrderId;


        $totalQty   = $request->get('totalQty');
        $totalValue = $request->get('totalValue');


        $countRows = count($request->get('qty'));

        $resultCart     = DB::table('mts_order')
                        ->where('order_status', 'Ordered')                        
                        ->where('fo_id',Auth::user()->id)                        
                        ->where('party_id',$retailerID)
                        ->orderBy('order_id','DESC')                         
                        ->first(); 

        if(sizeof($resultCart)> 0) 
        {

         $checkOrder     = DB::table('mts_order_details')
                        ->where('order_id', $resultCart->order_id)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$retailerID)                        
                        ->where('cat_id',$request->get('cat_id'))                        
                        ->delete(); 

         $checkCommission     = DB::table('mts_categroy_wise_commission')
                        ->where('order_id', $resultCart->order_id)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$retailerID)                        
                        ->where('cat_id',$request->get('cat_id'))                        
                        ->delete();
 
        }

        if(sizeof($resultCart)== 0) 
        {
           
            DB::table('mts_order')->insert(
                [
                    'order_no'              => $orderNo,
                    'order_date'            => date('Y-m-d h:i:s'),
                    'order_status'          => 'Ordered',
                    'total_order_qty'       => $totalQty,
                    'total_order_value'     => $totalValue,
                    'route_id'              => $request->get('route_id'),
                    'party_id'              => $request->get('retailer_id'),
                    'fo_id'                 => Auth::user()->id,
                    'global_company_id'     => Auth::user()->global_company_id,
                    'entry_by'              => Auth::user()->id,
                    'entry_date'            => date('Y-m-d h:i:s')
                    
                ]
            );

           $resultCart     = DB::table('mts_order')
                        ->where('order_status', 'Ordered')                        
                        ->where('fo_id',Auth::user()->id)                        
                        ->where('party_id',$retailerID)
                        ->orderBy('order_id','DESC')                         
                        ->first(); 
           

            for($m=0;$m<$countRows;$m++)
            {
                if($request->get('qty')[$m]!='')
                {
                    $totalPrice = $request->get('qty')[$m] * $request->get('price')[$m];


                    DB::table('mts_order_details')->insert(
                        [
                            'order_id'          => $resultCart->order_id,
                            'order_date'        => date('Y-m-d H:i:s'),
                            'cat_id'            => $request->get('category_id')[$m],
                            'product_id'        => $request->get('produuct_id')[$m],
                            'order_qty'         => $request->get('qty')[$m],
                            'p_unit_price'      => $request->get('price')[$m],
                            'order_total_value' => $totalPrice,
                            'order_det_status'  => 'Ordered',
                            'party_id'          => $retailerID,
                            'entry_by'          => Auth::user()->id,
                            'entry_date'        => date('Y-m-d h:i:s')

                        ]
                    );

                }

            }
         }else{ 

            for($m=0;$m<$countRows;$m++)
            {
                if($request->get('qty')[$m]!='')
                {
                    $totalPrice = $request->get('qty')[$m] * $request->get('price')[$m];


                    DB::table('mts_order_details')->insert(
                        [
                            'order_id'          => $resultCart->order_id,
                            'order_date'        => date('Y-m-d H:i:s'),
                            'cat_id'            => $request->get('category_id')[$m],
                            'product_id'        => $request->get('produuct_id')[$m],
                            'order_qty'         => $request->get('qty')[$m],
                            'p_unit_price'      => $request->get('price')[$m],
                            'order_total_value' => $totalPrice,
                            'order_det_status'  => 'Ordered',
                            'party_id'          => $retailerID,
                            'entry_by'          => Auth::user()->id,
                            'entry_date'        => date('Y-m-d h:i:s')

                        ]
                    );

                }

            }


            $totalOrder = DB::table('mts_order_details')

                        ->select(DB::raw('SUM(order_qty) AS totalQty'), DB::raw('SUM(order_total_value) AS totalValue'))
                        ->where('order_id', $resultCart->order_id)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$retailerID)
                        ->first();

             DB::table('mts_order')->where('order_id', $resultCart->order_id)                        
                ->where('entry_by',Auth::user()->id)                        
                ->where('party_id',$retailerID)->update(
                [
                    'total_order_qty'       => $totalOrder->totalQty,
                    'total_order_value'     => $totalOrder->totalValue,
                    'entry_date'            => date('Y-m-d h:i:s')
                    
                ]
            );

           
         }

            if(sizeof($request->get('commission'))>0){
                $commissionValue = ($totalValue * $request->get('commission'))/100;
                
                DB::table('mts_categroy_wise_commission')->insert(
                    [
                        'order_id'              => $resultCart->order_id,
                        'cat_id'                => $request->get('cat_id'),
                        'party_id'              => $request->get('retailer_id'),
                        'fo_id'                 => Auth::user()->id,
                        'order_value'           => $totalValue, 
                        'order_commission_value'      => $commissionValue,
                        'commission'            => $request->get('commission'),
                        'global_company_id'     => Auth::user()->global_company_id,
                        'entry_by'              => Auth::user()->id,
                        'entry_date'            => date('Y-m-d h:i:s')
                    ]
                );
            }
           
            return Redirect::to('/mts-order-process/'.$request->get('retailer_id').'/'.$request->get('route_id'))->with('success', 'Successfully Added Add To Cart.');
        

    }

    public function mts_bucket($routeid,$partyid){


        $selectedMenu   = 'Visit';             // Required Variable
        $pageTitle      = 'Bucket';           // Page Slug Title 

        $resultFoInfo   = DB::table('users')
                        ->select('users.id','users.email','tbl_user_type.user_type','tbl_user_business_scope.point_id','tbl_user_business_scope.division_id')
                         ->join('tbl_user_type', 'users.user_type_id', '=', 'tbl_user_type.user_type_id')
                         ->join('tbl_user_business_scope', 'tbl_user_business_scope.user_id', '=', 'users.id')
                         ->join('tbl_global_company', 'tbl_global_company.global_company_id', '=', 'users.global_company_id')
                         ->where('tbl_user_type.user_type_id', 12)
                         ->where('users.id', Auth::user()->id)
                         ->where('users.is_active', 0) // 0 for active
                         ->where('tbl_user_business_scope.is_active', 0) 
                         ->where('tbl_global_company.global_company_id', Auth::user()->global_company_id)
                         ->first(); 

       
         $resultCartPro  = DB::table('mts_order_details')
                        ->select('mts_order_details.cat_id','mts_order_details.order_id','tbl_product_category.id AS catid',
                        'tbl_product_category.name AS catname','mts_order.order_id','mts_order.fo_id','mts_order.order_status',
                        'mts_order.order_no','mts_order.party_id','mts_order_details.order_date') 
                        ->join('tbl_product_category', 'tbl_product_category.id', '=', 'mts_order_details.cat_id') 
                        ->join('mts_order', 'mts_order.order_id', '=', 'mts_order_details.order_id')
                        ->where('mts_order.order_status','Ordered')                        
                        ->where('mts_order.fo_id',Auth::user()->id)                        
                        ->where('mts_order.party_id',$partyid)
                        ->groupBy('mts_order_details.cat_id')                        
                        ->get();

            $resultInvoice  = DB::table('mts_order')->select('order_id','order_status','fo_id','party_id')
                        ->where('order_status', 'Ordered')                        
                        ->where('fo_id',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->first();

            $orderCommission = DB::table('mts_categroy_wise_commission') 
                        ->select('order_id','party_id',DB::raw('SUM(order_commission_value) AS commission'),'entry_by')
                        ->where('order_id', $resultInvoice->order_id)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->first();


        return view('ModernSales::sales/bucket',compact('selectedMenu','pageTitle','partyid','routeid','resultCartPro','resultInvoice','orderCommission'));
   

    }

    public function mts_items_edit(Request $request)
    {

        $partyid        = $request->get('partyid');
        $routeid        = $request->get('routeid');
        $catid          = $request->get('catid');
        
        $resultPro  = DB::table('mts_order_details')
                        ->select('mts_order_details.order_det_id','mts_order_details.order_id','mts_order_details.product_id',
                        'mts_order_details.order_qty','mts_order_details.order_qty',
                        'mts_order_details.p_unit_price','tbl_product.name')
                        ->join('tbl_product', 'tbl_product.id', '=', 'mts_order_details.product_id')
                        ->where('mts_order_details.order_det_id', $request->get('itemsid'))
                        ->first();

        $resultCatDefault  = DB::table('tbl_product_category')
                        ->select('id')                        
                        ->where('id', $request->get('catid'))
                        ->first();

        return view('ModernSales::sales/editItems', compact('resultPro','partyid','routeid','catid','resultCatDefault'));
    }


    public function mts_items_edit_submit(Request $request)
    {

        $partyid    = $request->get('partyid');
        $routeid    = $request->get('routeid');
        $catid      = $request->get('catid');
        $orderid    = $request->get('order_id');
        
        $price          = $request->get('items_qty') * $request->get('items_price');
        
        DB::table('mts_order_details')->where('order_det_id',$request->get('id'))->update(
            [
                'order_qty'         => $request->get('items_qty'), 
                'order_total_value' => $price, 
                'order_date'        => date('Y-m-d H:i:s') 
            ]
        );          
  
                    

        return Redirect::back()->with('success', 'Successfully Updated Order Product.');

    }

    public function mts_confirm_order($orderid,$partyid,$routeid)
    {

        $totalOrder = DB::table('mts_order_details')

                        ->select(DB::raw('SUM(order_qty) AS totalQty'), DB::raw('SUM(order_total_value) AS totalValue'))
                        ->where('order_id', $orderid)                        
                        ->where('entry_by',Auth::user()->id)                        
                        ->where('party_id',$partyid)
                        ->first();
             

        DB::table('mts_order')->where('order_id', $orderid)->where('fo_id', Auth::user()->id)->where('entry_by',Auth::user()->id)->update(
            [
                'order_status'  => 'Confirmed', 
                'order_date'    => date('Y-m-d H:i:s'),
                'total_order_qty'       => $totalOrder->totalQty,
                'total_order_value'     => $totalOrder->totalValue,
                'entry_date'            => date('Y-m-d h:i:s')
            ]
        );

        DB::table('mts_order_details')
                ->where('order_id', $orderid)
                ->update(
                    [
                        'order_det_status'          => 'Confirmed' 
                    ]
            );




    return Redirect::to('/mts-visit')->with('success', 'Successfully Confirmed Order');

    }
}
