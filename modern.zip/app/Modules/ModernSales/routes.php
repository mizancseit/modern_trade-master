<?php

Route::group(
    ['middleware' => ['web', 'auth'], 'module' => 'ModernSales', 'namespace' => 'App\Modules\ModernSales\Controllers'], function () {
        Route::get('/modernSales', 'ModernSalesController@index');

        /////////////////////Sharifur Rahman part of Start ////////////////////

        // Order for field Executive

        Route::get('/mts-visit', 'ModernVisitController@mts_visit');
        Route::get('/mts-partyList', 'ModernVisitController@mts_partyList');
        Route::get('/mts-order-process/{partyid}/{customer_id}', 'ModernVisitController@mts_order_process');
        Route::get('/mts-category-products', 'ModernVisitController@mts_category_products');
        Route::post('/mts-add-to-cart', 'ModernVisitController@mts_add_to_cart_products');

		Route::get('/mts-bucket/{customer_id}/{partyid}', 'ModernVisitController@mts_bucket');

		Route::post('/mts-items-edit', 'ModernVisitController@mts_items_edit');
		Route::post('/mts-edit-submit', 'ModernVisitController@mts_items_edit_submit');
		Route::get('/mts-items-delete/{orderid}/{itemid}/{customer_id}/{partyid}/{catid}', 'ModernVisitController@mts_items_delete');

		Route::post('/mts-confirm-order', 'ModernVisitController@mts_confirm_order');
 
		Route::get('/mts-delete-order/{orderid}/{partyid}/{customer_id}', 'ModernVisitController@mts_delete_order');


		// Report for field Executive

		Route::get('/mts-order-report', 'ModernExecutiveReportController@mts_order_report');
		Route::post('/mts-order-report-list', 'ModernExecutiveReportController@mts_order_report_list');
		Route::get('/mts-order-details/{orderMainId}', 'ModernExecutiveReportController@mts_order_details');

		Route::get('/mts-delivery-report', 'ModernExecutiveReportController@mts_delivery_report');
		Route::post('/mts-delivery-report-list', 'ModernExecutiveReportController@mts_delivery_report_list');
		Route::get('/mts-delivery-details/{orderMainId}', 'ModernExecutiveReportController@mts_delivery_details');

		// Not approve sales order

		Route::get('/mts-order-not-approve', 'ModernVisitController@mts_order_not_approve');
		Route::post('/mts-order-not-approve-list', 'ModernVisitController@mts_order_not_approve_list');
		// Modern Admin part

		Route::get('/mts-approved', 'ModernAdminController@mts_approved');
		Route::get('/mts-approved-list', 'ModernAdminController@mts_approved_list');

		Route::get('/mts-order-view/{wastageMainId}/{foMainId}', 'ModernAdminController@mts_order_view');

		Route::get('/mts-approved-order/{orderid}/{partyid}/{status}', 'ModernAdminController@mts_approved_order');

		Route::post('/not-approved-remarks-submit', 'ModernAdminController@not_approved_remarks_submit');
		

		// Delivery Approved for admin part

		Route::get('/mts-delivery-approved', 'ModernAdminController@mts_delivery_approved');
		Route::get('/mts-delivery-approved-list', 'ModernAdminController@mts_delivery_approved_list');

		Route::get('/mts-delivery-approved-view/{orderMainId}/{foMainId}', 'ModernAdminController@mts_delivery_approved_view');
		Route::get('/mts-approved-delivery/{orderid}/{customerid}/{status}', 'ModernAdminController@mts_approved_delivery');
		
		
		// Opening blance start

		Route::get('/mts-opening-route', 'ModernPaymentControlle@mts_opening_route');
        Route::get('/mts-opening-outlet', 'ModernPaymentControlle@mts_opening_outlet');
        Route::get('/mts-add-opening-balance', 'ModernPaymentControlle@mts_add_opening_balance');

        // delivery report part of admin

        Route::get('/mts-admin-delivery', 'ModernAdminController@ssg_report_order_delivery');
		Route::post('/mts-admin-delivery-list', 'ModernAdminController@ssg_report_order_list');
		Route::get('/mts-admin-delivery-details/{orderMainId}', 'ModernAdminController@ssg_order_details');

		// Payment report part of admin

		Route::get('/mts-admin-payment', 'ModernPaymentControlle@mts_admin_payment');
		Route::get('/mts-admin-payment-list', 'ModernPaymentControlle@mts_admin_payment_list');
		// Credit Adjustment

		Route::get('/credit-adjustment', 'ModernPaymentControlle@credit_adjustment');
		Route::get('/credit-adjustment-list', 'ModernPaymentControlle@credit_adjustment_list');
		Route::post('/credit-adjustment-process', 'ModernPaymentControlle@credit_adjustment_process');


		// Advance Replace start

        Route::get('/mts-replace', 'ModernReplaceController@mts_replace');
        Route::get('/mts-replace-outlet-list', 'ModernReplaceController@mts_replace_outlet_list');
        Route::get('/mts-replace-process/{partyid}/{customer_id}', 'ModernReplaceController@mts_replace_process');
        Route::get('/mts-replace-category-products', 'ModernReplaceController@mts_replace_category_products');
        Route::post('/mts-add-replace-products', 'ModernReplaceController@mts_add_replace_products');
		Route::get('/mts-replace-bucket/{customer_id}/{partyid}', 'ModernReplaceController@mts_replace_bucket');
		Route::post('/mts-replace-items-edit', 'ModernReplaceController@mts_replace_items_edit');
		Route::post('/mts-replace-edit-submit', 'ModernReplaceController@mts_replace_edit_submit');
		Route::get('/mts-replace-items-delete/{replace_id}/{itemid}', 'ModernReplaceController@mts_replace_items_delete');
		Route::post('/mts-confirm-replace', 'ModernReplaceController@mts_confirm_replace');
		Route::get('/mts-delete-replace/{replace_id}/{partyid}/{customer_id}', 'ModernReplaceController@mts_delete_replace');

		// Not approve Advance Replace

		Route::get('/mts-replace-not-approve', 'ModernReplaceController@mts_replace_not_approve');
		Route::post('/mts-replace-not-approve-list', 'ModernReplaceController@mts_replace_not_approve_list');

		// Advance Replace Modern Admin part

		Route::get('/mts-replace-approved', 'ModernReplaceController@mts_replace_approved');
		Route::get('/mts-replace-approved-list', 'ModernReplaceController@mts_replace_approved_list');

		Route::get('/mts-replace-view/{wastageMainId}/{foMainId}', 'ModernReplaceController@mts_replace_view');

		Route::get('/mts-approved-replace/{orderid}/{partyid}/{status}', 'ModernReplaceController@mts_approved_replace');

		// Advance Replace Modern Billing part

		Route::get('/mts-replace-delivery', 'ModernReplaceController@mts_replace_delivery');
		Route::get('/mts-replace-delivery-list', 'ModernReplaceController@mts_replace_delivery_list');

		Route::get('/mts-replace-delivery-edit/{DeliveryMainId}/{foMainId}', 'ModernReplaceController@mts_replace_delivery_edit');
		Route::post('/mts-replace-delivery-edit-submit', 'ModernReplaceController@mts_replace_delivery_edit_submit');

		// Advance Replace Delivery Report admin part

		Route::get('/mts-admin-replace-delivery-report', 'ModernReplaceController@mts_admin_replace_delivery_report');
		Route::get('/mts-admin-replace-delivery-report-list', 'ModernReplaceController@mts_admin_replace_delivery_report_list');
		Route::get('/mts-admin-replace-delivery-report-details/{orderMainId}', 'ModernReplaceController@mts_admin_replace_delivery_report_details');

		// Advance Replace Delivery Report Executive part

		Route::get('/mts-replace-delivery-report', 'ModernReplaceController@mts_replace_delivery_report');
		Route::get('/mts-replace-delivery-report-list', 'ModernReplaceController@mts_replace_delivery_report_list');
		Route::get('/mts-replace-delivery-report-details/{orderMainId}', 'ModernReplaceController@mts_replace_delivery_report_details');


		// Advance Replace Approved for admin part

		Route::get('/mts-replace-delivery-approved', 'ModernReplaceController@mts_replace_delivery_approved');
		Route::get('/mts-replace-delivery-approved-list', 'ModernReplaceController@mts_replace_delivery_approved_list');

		Route::get('/mts-replace-delivery-approved-view/{orderMainId}/{foMainId}', 'ModernReplaceController@mts_replace_delivery_approved_view');
		Route::get('/mts-replace-delivery-approved-submit/{orderid}/{customerid}/{status}', 'ModernReplaceController@mts_replace_delivery_approved_submit');

		// Return start

        Route::get('/mts-return', 'ModernReturnController@mts_return');
        Route::get('/mts-return-outlet-list', 'ModernReturnController@mts_return_outlet_list');
        Route::get('/mts-return-process/{partyid}/{customer_id}', 'ModernReturnController@mts_return_process');
        Route::get('/mts-return-category-products', 'ModernReturnController@mts_return_category_products');
        Route::post('/mts-add-return-products', 'ModernReturnController@mts_add_return_products');
		Route::get('/mts-return-bucket/{customer_id}/{partyid}', 'ModernReturnController@mts_return_bucket');
		Route::post('/mts-return-items-edit', 'ModernReturnController@mts_return_items_edit');
		Route::post('/mts-return-edit-submit', 'ModernReturnController@mts_return_edit_submit');
		Route::get('/mts-return-items-delete/{return_id}/{itemid}', 'ModernReturnController@mts_return_items_delete');
		Route::post('/mts-confirm-return', 'ModernReturnController@mts_confirm_return');
		Route::get('/mts-delete-return/{return_id}/{partyid}/{customer_id}', 'ModernReturnController@mts_delete_return'); 
		// Not approve Advance Replace

		Route::get('/mts-return-not-approve', 'ModernReturnController@mts_return_not_approve');
		Route::post('/mts-return-not-approve-list', 'ModernReturnController@mts_return_not_approve_list');

		// Return Modern Admin part

		Route::get('/mts-return-approved', 'ModernReturnController@mts_return_approved');
		Route::get('/mts-return-approved-list', 'ModernReturnController@mts_return_approved_list');

		Route::get('/mts-return-view/{wastageMainId}/{foMainId}', 'ModernReturnController@mts_return_view');

		Route::get('/mts-approved-return/{orderid}/{partyid}/{status}', 'ModernReturnController@mts_approved_return');

		// Return Modern Billing part

		Route::get('/mts-return-delivery', 'ModernReturnController@mts_return_delivery');
		Route::get('/mts-return-delivery-list', 'ModernReturnController@mts_return_delivery_list');

		Route::get('/mts-return-delivery-edit/{DeliveryMainId}/{foMainId}', 'ModernReturnController@mts_return_delivery_edit');
		Route::post('/mts-return-delivery-edit-submit', 'ModernReturnController@mts_return_delivery_edit_submit');

		// Return Delivery Report admin part

		Route::get('/mts-admin-return-delivery-report', 'ModernReturnController@mts_admin_return_delivery_report');
		Route::get('/mts-admin-return-delivery-report-list', 'ModernReturnController@mts_admin_return_delivery_report_list');
		Route::get('/mts-admin-return-delivery-report-details/{orderMainId}', 'ModernReturnController@mts_admin_return_delivery_report_details');

		// Return Delivery Report Executive part

		Route::get('/mts-return-delivery-report', 'ModernReturnController@mts_return_delivery_report');
		Route::get('/mts-return-delivery-report-list', 'ModernReturnController@mts_return_delivery_report_list');
		Route::get('/mts-return-delivery-report-details/{orderMainId}', 'ModernReturnController@mts_return_delivery_report_details');

		/////////////////////Sharifur Rahman part of End////////////////////

		
		/////////////////////Md. Sazzadul islam////////////////////

		Route::post('/orderDelivery-open-submit', 'ModernDeliveryController@ssg_modern_open_submit');
		Route::get('/product-wise-analysis/{id}', 'ModernDeliveryController@product_wise_analysis');
		Route::get('/modern-reqAllAnalysisList', 'ModernDeliveryController@modern_delivery_analysis');
		Route::get('/modern-reqAllAnalysisList-view', 'ModernDeliveryController@modern_delivery_analysis_list');

		Route::get('/modern-delivery-list', 'ModernDeliveryController@ssg_delivery_list');


		Route::get('/modern-delivery', 'ModernDeliveryController@modern_delivery');
		Route::get('/modern-delivery-list', 'ModernDeliveryController@ssg_delivery_list');

		Route::get('/orderDelivery-edit/{wastageMainId}/{foMainId}', 'ModernDeliveryController@ssg_order_edit');
		Route::post('/orderDelivery-edit-submit', 'ModernDeliveryController@ssg_modern_edit_submit');

		
		Route::get('/moderndelivery', 'ModernDeliveryController@ssg_report_order_delivery');
		Route::post('/moderndelivery-list', 'ModernDeliveryController@ssg_report_order_list');
		Route::get('/modernorder-details/{orderMainId}', 'ModernDeliveryController@ssg_order_details');
		//////////////payment////////////////
		
		Route::get('/outlet_payments', 'ModernPaymentControlle@outlet_payments');
		Route::get('/outlet-payment-list', 'ModernPaymentControlle@outlet_payment_list');
		Route::post('/outlet_paymnet_process', 'ModernPaymentControlle@outlet_paymnet_process');

		Route::get('/admin_payments_con', 'ModernPaymentControlle@admin_payments_con');
		Route::get('/admin_payments_con_list', 'ModernPaymentControlle@admin_payments_con_list');
		Route::get('/app_admin_payment/{id}/{status}', 'ModernPaymentControlle@app_admin_payment');

		Route::get('/app_admin_payment_edit', 'ModernPaymentControlle@app_admin_payment_edit');
		Route::post('/app_admin_payment_edit_submit', 'ModernPaymentControlle@app_admin_payment_edit_submit');

		Route::get('/accounts_payments_con', 'ModernPaymentControlle@accounts_payments_con');
		Route::get('/accounts_payments_con_list', 'ModernPaymentControlle@accounts_payments_con_list');
		Route::post('/account_payment_receive', 'ModernPaymentControlle@account_payment_receive');
		Route::get('/accounts_payments_rece_report', 'ModernPaymentControlle@accounts_payments_rece_report');
		Route::get('/accounts_payments_rece_report_list', 'ModernPaymentControlle@accounts_payments_rece_report_list');

		//// customer ledger report/////

		Route::get('/customer-ledger', 'ModernAdminController@customer_ledger');
		Route::post('/customer-ledger-list', 'ModernAdminController@customer_ledger_list');

		//// customer Stock report/////

		Route::get('/customer-stock', 'ModernAdminController@customer_stock');
		Route::post('/customer-stock-list', 'ModernAdminController@customer_stock_list');

		///////add user////
		Route::get('/addUser', 'ModernAdminController@addUser');



			// Analysis Requisition Manage

			//Route::get('/modern-reqPendingList', 'BillingRequisition@req_pending_list');
			Route::post('/modern-reqAcknowledge', 'ModernDeliveryController@req_acknowledge_new');

			// Route::get('/modern-reqAllAnalysisList', 'BillingRequisition@req_analysis_list_new');
			Route::get('/modern-reqOrderAnalysis/{prodid}/{div_id}', 'BillingRequisition@req_order_analysis_new');

			Route::post('/modern-reqApproved', 'BillingRequisition@req_approved_new');
			Route::get('/modern-reqAllApprovedList', 'BillingRequisition@req_all_approved_list');

			Route::get('/modern-reqBilled/{reqid}', 'BillingRequisition@req_billed_process');
			Route::get('/modern-reqBilledList', 'BillingRequisition@req_billed_list');
			Route::get('/modern-reqAllBilledList', 'BillingRequisition@req_all_billed_list');
			Route::get('/modern-reqBillDetails/{reqid}', 'BillingRequisition@req_bill_details_list');

			Route::get('/modern-reqOpenOrderList/{reqid}', 'BillingRequisition@req_open_order_list');

			Route::get('modern-export-sales-order', 'BillingRequisition@export_sale_order');

			// Master list

			Route::get('modern-manager-list', 'ModernAdminController@manager_list'); 
			Route::get('modern-executive-list', 'ModernAdminController@executive_list');
			Route::get('modern-officer-list', 'ModernAdminController@officer_list');

			// --- Sharif start target file upload -- //

			Route::get('/modern_target_upload','MasterUploadController@modern_target_list');
			Route::post('/modern_target_file_upload','MasterUploadController@modernTargetUpload');
			Route::get('/modern_target_edit','MasterUploadController@modern_target_edit');
			Route::post('/modern_target_edit_process','MasterUploadController@modern_target_edit_process');

			Route::get('/modernTargetDelete','MasterUploadController@modernTargetDelete');
    }
);