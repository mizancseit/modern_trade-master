<?php

namespace App\Models\sales;

use Illuminate\Database\Eloquent\Model;

class SpecialOfferProductModel extends Model
{
    protected $table = 'tbl_special_offer_product';
}
