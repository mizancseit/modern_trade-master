{{-- Master Menu  --}} 

<div class="menu">
    <ul class="list">
    {{-- <li class="header">MAIN NAVIGATION</li> --}}
        @php 
            $selectedSubMenu='';
        @endphp

        <li @if($selectedMenu=='Home') class="active" @endif>
            <a href="{{ URL('/') }}">
                <i class="material-icons">dashboard</i>
                <span>Dashboard</span>
            </a>
        </li>
        @if(Auth::user()->module_type==2 && Auth::user()->user_type_id==1)
        <li @if($selectedMenu=='globalcompany') class="active" @endif>
            <a href="{{ URL('/mts-visit') }}">
                <i class="material-icons">view_list</i>
                <span>Sales Order</span>
            </a>    
        </li>

        <li @if($selectedMenu=='Sales Report') class="active" @endif>
            <a href="javascript:void(0);" class="menu-toggle">
                <i class="material-icons">view_list</i>
                <span>Sales Report</span>
            </a>

            <ul class="ml-menu">
                      <!--Maung Master Menu-->
                <li @if($selectedSubMenu=='Order Report') class="active" @endif>
                    <a href="{{ URL('/mts-order-report') }}">
                        <i class="material-icons">view_list</i>
                        <span>Order Report</span>
                    </a>    
                </li>
                <li @if($selectedSubMenu=='Delivery Report') class="active" @endif>
                    <a href="{{ URL('/mts-delivery-report') }}">
                        <i class="material-icons">view_list</i>
                        <span>Delivery Report</span>
                    </a>    
                </li>
            </ul>
        </li>
        @endif
        @if(Auth::user()->module_type==2  && Auth::user()->user_type_id==2)
        <li @if($selectedMenu=='Delivery') class="active" @endif>
            <a href="{{ URL('/modern-delivery') }}">
                <i class="material-icons">view_list</i>
                <span>Sales Order</span>
            </a>    
        </li>
        <li @if($selectedMenu=='Report') class="active" @endif>
            <a href="{{ URL('/moderndelivery') }}">
                <i class="material-icons">view_list</i>
                <span>Delivery Report</span>
            </a>    
        </li>
        @endif
        
        

        <li class="header"></li>
       {{--  <li @if($selectedMenu=='Password') class="active" @endif>
            <a href="{{ URL('/password/change-password') }}">
                <i class="material-icons">person</i>
                <span>Change Password</span>
            </a>            
        </li> --}}

        <li>
            <a href="{{ URL('/logout') }}" onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                <i class="material-icons col-light-blue">donut_large</i>
                <span>Sign Out</span>
            </a>
            <form id="logout-form" action="{{ URL('/logout') }}" method="POST" style="display: none;">
                {{ csrf_field() }}
            </form>
        </li>

        <li class="header"></li>

    </ul>
</div>



