<?php

namespace App\Models\sales;

use Illuminate\Database\Eloquent\Model;

class DepotSetupModel extends Model
{
    protected $table = 'tbl_depot_setup';
    //protected $fillable = ['depot_id','updated_by', 'depot_status'];
}
