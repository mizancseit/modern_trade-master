<?php

namespace App\Models\sales;

use Illuminate\Database\Eloquent\Model;

class OfferSetupModel extends Model
{
    protected $table = 'tbl_regular_special_offer';
}
