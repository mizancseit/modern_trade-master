<?php

namespace App\Modules\ModernSales\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Hash;
use DB;
use Auth;
use Session;
use Excel;

class MasterUploadController extends Controller
{
    // --- Sharif start target file upload -- //


  public function modern_target_list()
  {
        $selectedMenu    = 'Targer file upload';            // Required Variable for menu
        $selectedSubMenu = 'Targer file upload';           // Required Variable for menu
        $pageTitle       = 'Targer file upload';          // Page Slug Title 

        $targetList  = DB::table('mts_target_upload') 
        ->select('mts_customer_list.name as cusname','tbl_product_category.name as cname','mts_target_upload.*')
        ->join('tbl_product_category', 'tbl_product_category.id', '=', 'mts_target_upload.cat_id')
        ->join('tbl_product', 'tbl_product.id', '=', 'mts_target_upload.product_id') 
        ->join('mts_customer_list', 'mts_customer_list.sap_code', '=', 'mts_target_upload.customer_id') 
        ->where('mts_target_upload.month', date('m'))
        ->where('mts_target_upload.year', date('Y'))
        ->orderBy('mts_target_upload.id','DESC')                    
        ->get();

         $managementlist = DB::table('mts_role_hierarchy')
          ->join('users', 'users.id', '=', 'mts_role_hierarchy.management_id')     
          ->where('mts_role_hierarchy.supervisor_id', Auth::user()->id)
          ->groupBy('mts_role_hierarchy.management_id')
          ->get();

        $MonthList = array('01'=>'January','02'=>'February','03'=>'March','04'=>'April','05'=>'May','06'=>'June','07'=>'July',
          '08'=>'August','09'=>'September','10'=>'October','11'=>'November','12'=>'December');

        return view('ModernSales::sales/target/fo_target_upload' , compact('selectedMenu','selectedSubMenu','pageTitle','targetList','channelName','resultDivision','MonthList','managementlist'));
      }

      public function modern_target_search(Request $request)
      {
        //dd($request->all());
        $startData = $request->year.'-'.$request->month.'-01';
        $endData   = $request->year.'-'.$request->month.'-31';

        //dd($startData,$endData);

        if($request->get('fos')!='')
        {
           

         $targetList = DB::table('mts_target_upload') 
        ->join('tbl_product_category', 'tbl_product_category.id', '=', 'mts_target_upload.cat_id')
        ->join('tbl_product', 'tbl_product.id', '=', 'mts_target_upload.product_id') 
        ->where('mts_target_upload.month', date('m'))
        ->where('mts_target_upload.year', date('Y'))
        ->orderBy('mts_target_upload.id','DESC')                    
        ->get();

        }
        elseif($request->get('fos')=='')
        {
          $targetList = DB::table('mts_target_upload') 
          ->join('tbl_product_category', 'tbl_product_category.id', '=', 'mts_target_upload.cat_id')
          ->join('tbl_product', 'tbl_product.id', '=', 'mts_target_upload.product_id') 
          ->where('mts_target_upload.month', date('m'))
          ->where('mts_target_upload.year', date('Y'))
          ->orderBy('mts_target_upload.id','DESC')                    
          ->get();
        }        

        return view('ModernSales::sales/target/fo_target_search' , compact('targetList'));
      }
 


      public function modernTargetUpload(Request $request)
      {
        if($request->file('imported-file'))
        {
          $path = $request->file('imported-file')->getRealPath();
          $data = Excel::load($path, function($reader) {})->get();
 
			
			if(!empty($data) && $data->count()){

       
        $data = $data->toArray();
        for($i=0;$i<count($data);$i++)
        {

          $cus_info = DB::table('mts_customer_list') 
          ->join('mts_customer_define_executive', 'mts_customer_define_executive.customer_id', '=', 'mts_customer_list.customer_id')
          ->join('mts_role_hierarchy', 'mts_role_hierarchy.officer_id', '=', 'mts_customer_define_executive.executive_id') 
          ->where('mts_customer_list.sap_code', $data[$i]['customer_id'])
          ->groupBy('mts_customer_list.sap_code')                    
          ->first(); 

          if (sizeof($cus_info)>0) {
            
           $insert = DB::table('mts_target_upload')->insert(
                [
                    'management_id'               => $cus_info->management_id,
                    'manager_id'                  => $cus_info->manager_id,
                    'executive_id'                => $cus_info->executive_id,
                    'officer_id'                  => $cus_info->officer_id,
                    'customer_id'                 => $data[$i]['customer_id'],
                    'year'                        => $data[$i]['year'],
                    'month'                       => $data[$i]['month'],
                    'cat_id'                      => $data[$i]['cat_id'],
                    'product_id'                  => $data[$i]['product_id'],
                    'material_code'               => $data[$i]['material_code'],
                    'qty'                         => $data[$i]['qty'],
                    'unit_price'                  => $data[$i]['unit_price'],
                    'value'                       => $data[$i]['qty'] * $data[$i]['unit_price'],
                    'created_by'                  => Auth::user()->id,
                    'created_at'                  => date('Y-m-d h:i:s')
                    
                ]
            );
          }
  
          
           

          // $insert[] = ['division_id'=> $data[$i]['division_id'], 'territory_id'=> $data[$i]['territory_id'], 'point_id'=> $data[$i]['point_id'], 'employee_id'=> $data[$i]['employee_id'],'global_company_id' =>Auth::user()->global_company_id, 'cat_id' => $data[$i]['cat_id'], 'cat_name' => $data[$i]['cat_name'], 'qty' => $data[$i]['qty'], 'avg_value' => $data[$i]['avg_value'], 'total_value' => $data[$i]['total_value'], 'start_date' => $sDate,'end_date' => $eDate,'created_by' => Auth::user()->id];
          
        }
        
        if(!empty($insert)){
          
         //MasterUploadModel::insert($insert);
         DB::table('mts_target_upload')
         ->where('qty', 0)
         ->delete();
         
         return back()->with('success','Target upload sucessfully.');
       }


     }

     
   }

   return back()->with('error','Please Check your file, Something is wrong there.');

 }

 public function modern_target_edit(Request $request)
 {

        $selectedMenu    = 'Targer file upload';                    // Required Variable for menu
        $selectedSubMenu = 'Targer file upload';           // Required Variable for menu
        $pageTitle       = 'Targer file upload'; // Page Slug Title
        $pcategory=DB::table('tbl_product_category')->get();

        $slID=$request->get('id');
        $targetList  = DB::table('tbl_fo_target')
        ->where('id',$slID)
        ->first();
        return view('ModernSales::sales/target//fo_target_edit',compact('selectedMenu','selectedSubMenu','pageTitle','targetList','pcategory')); 

      }

      public function modern_target_edit_process(Request $request){

        $target = MasterUploadModel::find($request->get('id'));

        $sDate = date('Y-m-d', strtotime($request->start_date));
        $eDate = date('Y-m-d', strtotime($request->end_date));
        
        $target->employee_id    = $request->employee_id;
        $target->cat_id         = $request->category;
        $target->qty            = $request->qty;
        $target->avg_value      = $request->avg_value;
        $target->total_value    = $request->avg_value * $request->qty;
        $target->start_date     = $sDate;
        $target->end_date       = $eDate; 
        $target->updated_by     = Auth::user()->id; 
        $target->save();
        return back()->with('success','Target upload sucessfully.');
       //return redirect('Master/fo_target_upload')->with('success','Target Update sucessfully.');
        
      }


      public function modernTargetDelete(Request $request)
      {
        $target = MasterUploadModel::find($request->get('id'));
        $target->delete();

        return back()->with('success','Target Delete sucessfully.');
      //return redirect('Master/fo_target_upload')->with('success','Target Delete sucessfully.');
      }

      
  }
