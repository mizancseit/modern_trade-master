<?php

namespace App\Models\sales;

use Illuminate\Database\Eloquent\Model;

class OfferValueWiseSetupModel extends Model
{
    protected $table = 'tbl_special_values_wise';
}
