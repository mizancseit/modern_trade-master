<?php

namespace App\Modules\Github\Models;

use Illuminate\Database\Eloquent\Model;

class Github extends Model
{
    //
}
