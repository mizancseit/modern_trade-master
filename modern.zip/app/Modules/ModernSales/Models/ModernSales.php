<?php

namespace App\Modules\ModernSales\Models;

use Illuminate\Database\Eloquent\Model;

class ModernSales extends Model
{
    //
}
