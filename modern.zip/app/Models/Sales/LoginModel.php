<?php

namespace App\Models\Sales;

use Illuminate\Database\Eloquent\Model;

class LoginModel extends Model
{
    //
}
